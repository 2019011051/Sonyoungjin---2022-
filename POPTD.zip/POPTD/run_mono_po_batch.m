function result = run_mono_po_batch(matFile, outputDir, cfgInput)
% run_mono_po_batch.m
% Project: PO+PTD RCS module development
% Description:
%   GUI 없이 PoFacets monostatic PO-only RCS 해석을 batch로 실행하는 파일임.
%   input .mat 파일에서 coord, facet을 읽고 CalcMono_core.m을 호출한 뒤,
%   PIAnO/RCE 연동이 가능한 txt/csv/mat 결과 파일을 저장함.
%
% Usage:
%   result = run_mono_po_batch();
%   result = run_mono_po_batch('input/case_pofacets.mat','output');
%   result = run_mono_po_batch('input/case_pofacets.mat','output', cfg);
%   result = run_mono_po_batch('input/case_pofacets.mat','output','input/rcs_config.json');
%
% Required files in the same POPTD folder:
%   - run_mono_po_batch.m
%   - CalcMono_core.m
%   - facetRCS.m
%   - input/case_pofacets.mat  containing coord and facet
%
% Output files:
%   - output/avgrcs.txt
%   - output/maxrcs.txt
%   - output/minrcs.txt
%   - output/RCS_CURVE.csv
%   - output/RCS_RESULT.txt
%   - output/RCS_OUTPUT.mat

    % ------------------------------------------------------------------
    % 0. Path setup
    % ------------------------------------------------------------------
    thisDir = fileparts(mfilename('fullpath'));
    if isempty(thisDir)
        thisDir = pwd;
    end
    addpath(thisDir);

    if nargin < 1 || isempty(matFile)
        matFile = fullfile(thisDir, 'input', 'case_pofacets.mat');
    end
    if nargin < 2 || isempty(outputDir)
        outputDir = fullfile(thisDir, 'output');
    end
    if nargin < 3
        cfgInput = [];
    end

    if ~isfolder(outputDir)
        mkdir(outputDir);
    end

    % ------------------------------------------------------------------
    % 1. Check required code files
    % ------------------------------------------------------------------
    if exist('CalcMono_core', 'file') ~= 2
        error('run_mono_po_batch:MissingFile', ...
              'CalcMono_core.m 파일이 현재 폴더 또는 MATLAB path에 없음.');
    end
    if exist('facetRCS', 'file') ~= 2
        error('run_mono_po_batch:MissingFile', ...
              'facetRCS.m 파일이 현재 폴더 또는 MATLAB path에 없음.');
    end

    % ------------------------------------------------------------------
    % 2. Load PoFacets geometry model
    % ------------------------------------------------------------------
    if exist(matFile, 'file') ~= 2
        error('run_mono_po_batch:InputError', '형상 .mat 파일을 찾을 수 없음: %s', matFile);
    end

    model = load(matFile);
    if ~isfield(model, 'coord') || ~isfield(model, 'facet')
        error('run_mono_po_batch:InputError', ...
              '.mat 파일 안에 coord와 facet 변수가 모두 있어야 함.');
    end

    coord = model.coord;
    facet = model.facet;

    % ------------------------------------------------------------------
    % 3. Build analysis configuration
    % ------------------------------------------------------------------
    cfg = default_mono_po_cfg();

    if isstruct(cfgInput)
        cfg = merge_struct(cfg, cfgInput);
    elseif ischar(cfgInput) || isstring(cfgInput)
        cfgFile = char(cfgInput);
        if exist(cfgFile, 'file') ~= 2
            error('run_mono_po_batch:InputError', 'cfg 파일을 찾을 수 없음: %s', cfgFile);
        end
        cfgFromFile = jsondecode(fileread(cfgFile));
        cfg = merge_struct(cfg, cfgFromFile);
    elseif ~isempty(cfgInput)
        error('run_mono_po_batch:InputError', ...
              'cfgInput은 struct, JSON 파일 경로, 또는 빈 값이어야 함.');
    end

    cfg.matFile = matFile;
    cfg.outputDir = outputDir;

    % ------------------------------------------------------------------
    % 4. Run monostatic PO-only solver
    % ------------------------------------------------------------------
    fprintf('--- run_mono_po_batch started ---\n');
    fprintf('Model file : %s\n', matFile);
    fprintf('Output dir : %s\n', outputDir);
    fprintf('Frequency  : %.6g GHz\n', cfg.freq);
    fprintf('Theta      : %.6g : %.6g : %.6g deg\n', cfg.tstart, cfg.delt, cfg.tstop);
    fprintf('Phi        : %.6g : %.6g : %.6g deg\n', cfg.pstart, cfg.delp, cfg.pstop);

    result = CalcMono_core(coord, facet, cfg);

    % ------------------------------------------------------------------
    % 5. Export results for PIAnO/RCE and post-processing
    % ------------------------------------------------------------------
    export_batch_results(result, outputDir);

    fprintf('RCS_avg    : %.10g dBsm\n', result.metrics.RCS_avg_dBsm);
    fprintf('RCS_max    : %.10g dBsm\n', result.metrics.RCS_max_dBsm);
    fprintf('RCS_min    : %.10g dBsm\n', result.metrics.RCS_min_dBsm);
    fprintf('--- run_mono_po_batch finished ---\n');

end

% -------------------------------------------------------------------------
function cfg = default_mono_po_cfg()
%DEFAULT_MONO_PO_CFG 초기 PO-only monostatic RCS 해석 기본값임.
% PoFacets 좌표계 기준: theta=90 deg 고정, phi=0~360 deg sweep.

    cfg = struct();
    cfg.C = 299792458;

    % Existing CalcMono convention uses GHz.
    cfg.freq = 10;

    % Horizontal azimuth sweep in PoFacets convention.
    cfg.tstart = 90;
    cfg.tstop  = 90;
    cfg.delt   = 1;

    cfg.pstart = 0;
    cfg.pstop  = 360;
    cfg.delp   = 1;

    % 1: theta-pol, 2: phi-pol
    cfg.i_pol = 1;

    % Free-space, PEC/Rs based, no roughness/diffuse correction.
    cfg.rsmethod = 1;
    cfg.iflag = 0;
    cfg.corr = 0;
    cfg.std = 0;
    cfg.Nt = 10;
    cfg.Lt = 0.01;
    cfg.useground = 0;
    cfg.usesymmetry = 0;
    cfg.clipMode = 'none';

end

% -------------------------------------------------------------------------
function s = merge_struct(s, u)
%MERGE_STRUCT u에 있는 field로 s의 field를 덮어씀.
    if isempty(u)
        return;
    end
    names = fieldnames(u);
    for k = 1:numel(names)
        s.(names{k}) = u.(names{k});
    end
end

% -------------------------------------------------------------------------
function export_batch_results(result, outputDir)
%EXPORT_BATCH_RESULTS RCS 결과를 txt/csv/mat로 저장함.

    avgrcsFile = fullfile(outputDir, 'avgrcs.txt');
    maxrcsFile = fullfile(outputDir, 'maxrcs.txt');
    minrcsFile = fullfile(outputDir, 'minrcs.txt');
    curveFile  = fullfile(outputDir, 'RCS_CURVE.csv');
    resultFile = fullfile(outputDir, 'RCS_RESULT.txt');
    matOutFile = fullfile(outputDir, 'RCS_OUTPUT.mat');

    % PIAnO/RCE가 숫자만 읽기 쉽도록 txt에는 숫자만 저장함.
    write_scalar_txt(avgrcsFile, result.metrics.RCS_avg_dBsm);
    write_scalar_txt(maxrcsFile, result.metrics.RCS_max_dBsm);
    write_scalar_txt(minrcsFile, result.metrics.RCS_min_dBsm);

    % Angle-wise curve export.
    phiCol   = result.phi(:);
    thetaCol = result.theta(:);
    SthCol   = result.Sth_raw(:);
    SphCol   = result.Sph_raw(:);

    if strcmpi(result.metrics.selected_pol, 'theta')
        selectedCol = SthCol;
    else
        selectedCol = SphCol;
    end

    T = table(thetaCol, phiCol, SthCol, SphCol, selectedCol, ...
        'VariableNames', {'theta_deg','phi_deg','Sth_dBsm','Sph_dBsm','selected_RCS_dBsm'});
    writetable(T, curveFile);

    % Human-readable summary.
    fid = fopen(resultFile, 'w');
    if fid < 0
        error('run_mono_po_batch:OutputError', '결과 파일을 열 수 없음: %s', resultFile);
    end
    cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>

    fprintf(fid, 'PO-only monostatic RCS batch result\n');
    fprintf(fid, 'selected_pol : %s\n', result.metrics.selected_pol);
    fprintf(fid, 'freq_GHz     : %.12g\n', result.wave.freqGHz);
    fprintf(fid, 'lambda_m     : %.12g\n', result.wave.lambda);
    if isfield(result, 'mesh') && isfield(result.mesh, 'nvert')
    fprintf(fid, 'nvert        : %d\n', result.mesh.nvert);
    else
    fprintf(fid, 'nvert        : N/A\n');
    end

    if isfield(result, 'mesh') && isfield(result.mesh, 'ntria')
    fprintf(fid, 'ntria        : %d\n', result.mesh.ntria);
    else
    fprintf(fid, 'ntria        : N/A\n');
    end
    fprintf(fid, 'theta_start  : %.12g\n', result.cfg.tstart);
    fprintf(fid, 'theta_stop   : %.12g\n', result.cfg.tstop);
    fprintf(fid, 'theta_step   : %.12g\n', result.cfg.delt);
    fprintf(fid, 'phi_start    : %.12g\n', result.cfg.pstart);
    fprintf(fid, 'phi_stop     : %.12g\n', result.cfg.pstop);
    fprintf(fid, 'phi_step     : %.12g\n', result.cfg.delp);
    fprintf(fid, 'RCS_avg_dBsm : %.12g\n', result.metrics.RCS_avg_dBsm);
    fprintf(fid, 'RCS_max_dBsm : %.12g\n', result.metrics.RCS_max_dBsm);
    fprintf(fid, 'RCS_min_dBsm : %.12g\n', result.metrics.RCS_min_dBsm);

    save(matOutFile, 'result');
end

% -------------------------------------------------------------------------
function write_scalar_txt(fileName, value)
%WRITE_SCALAR_TXT 숫자 하나만 저장함.
    fid = fopen(fileName, 'w');
    if fid < 0
        error('run_mono_po_batch:OutputError', '파일을 열 수 없음: %s', fileName);
    end
    cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
    fprintf(fid, '%.12g\n', value);
end
