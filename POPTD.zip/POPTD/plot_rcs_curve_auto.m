function T = plot_rcs_curve_auto(result, unitMode, componentMode, addSphereRef)
%PLOT_RCS_CURVE_AUTO Plot monostatic RCS result automatically.
%
% Usage:
%   plot_rcs_curve_auto(result_PO_old)
%   plot_rcs_curve_auto(result_PO_old, 'dbsm')
%   plot_rcs_curve_auto(result_PO_old, 'm2')
%   plot_rcs_curve_auto(result_PO_old, 'dbsm', 'th')
%   plot_rcs_curve_auto(result_PO_old, 'dbsm', 'ph')
%   plot_rcs_curve_auto(result_PO_old, 'dbsm', 'total')
%
% Inputs:
%   result        : result structure from PO or PO/PTD solver
%   unitMode      : 'dbsm' or 'm2'
%   componentMode : 'auto', 'th', 'ph', 'total', 'co'
%   addSphereRef  : true or false
%
% Purpose:
%   theta sweep이면 theta를 x축으로 사용함.
%   phi sweep이면 phi를 x축으로 사용함.
%   phi가 0으로 고정되어 있어도 xlim 오류가 안 나도록 함.

if nargin < 1 || isempty(result)
    result = find_result_in_base();
end

if nargin < 2 || isempty(unitMode)
    unitMode = 'dbsm';
end

if nargin < 3 || isempty(componentMode)
    componentMode = 'auto';
end

if nargin < 4 || isempty(addSphereRef)
    addSphereRef = true;
end

unitMode = lower(string(unitMode));
componentMode = lower(string(componentMode));

% ------------------------------------------------------------
% 1. Extract theta and phi
% -------------------------------------------------------------
[theta_deg, phi_deg] = extract_angles(result);

% ------------------------------------------------------------
% 2. Extract RCS
% -------------------------------------------------------------
[RCS_linear, RCS_dBsm, usedComponent] = extract_rcs(result, componentMode);

RCS_linear = RCS_linear(:);
RCS_dBsm   = RCS_dBsm(:);

nCase = numel(RCS_dBsm);

theta_deg = reshape_angle_vector(theta_deg, nCase);
phi_deg   = reshape_angle_vector(phi_deg, nCase);

% ------------------------------------------------------------
% 3. Decide x-axis
% -------------------------------------------------------------
theta_unique = unique(theta_deg(isfinite(theta_deg)));
phi_unique   = unique(phi_deg(isfinite(phi_deg)));

if numel(theta_unique) > 1 && numel(phi_unique) == 1
    x = theta_deg(:);
    xLabel = '\theta [deg]';
    sweepName = 'Theta sweep';

elseif numel(phi_unique) > 1 && numel(theta_unique) == 1
    x = phi_deg(:);
    xLabel = '\phi [deg]';
    sweepName = 'Phi sweep';

elseif numel(theta_unique) > 1 && numel(phi_unique) > 1
    x = (1:nCase).';
    xLabel = 'Case index';
    sweepName = '2D theta-phi sweep';

else
    x = (1:nCase).';
    xLabel = 'Case index';
    sweepName = 'Single-angle or unknown sweep';
end

% ------------------------------------------------------------
% 4. Select y-axis unit
% -------------------------------------------------------------
switch unitMode
    case {"dbsm", "db"}
        y = RCS_dBsm;
        yLabel = 'Radar Cross Section [dBsm]';
        refValue = 10*log10(pi);
        refLabel = '\pi a^2 = 4.97 dBsm';

    case {"m2", "linear", "lin"}
        y = RCS_linear;
        yLabel = 'Radar Cross Section [m^2]';
        refValue = pi;
        refLabel = '\pi a^2 = 3.1416 m^2';

    otherwise
        error('Unknown unitMode. Use ''dbsm'' or ''m2''.');
end

% ------------------------------------------------------------
% 5. Plot
% -------------------------------------------------------------
figure;
plot(x, y, 'LineWidth', 1.5);
hold on;

if addSphereRef
    yline(refValue, '--', refLabel);
end

grid on;
xlabel(xLabel);
ylabel(yLabel);

title(sprintf('%s, component = %s', sweepName, usedComponent), ...
    'Interpreter', 'none');

if numel(x) > 1 && min(x) < max(x)
    xlim([min(x), max(x)]);
else
    xlim([x(1)-1, x(1)+1]);
end

% ------------------------------------------------------------
% 6. Print summary
% -------------------------------------------------------------
fprintf('\n--- plot_rcs_curve_auto summary ---\n');
fprintf('Sweep type       : %s\n', sweepName);
fprintf('Used component   : %s\n', usedComponent);
fprintf('Unit mode        : %s\n', unitMode);
fprintf('Number of cases  : %d\n', nCase);
fprintf('theta range      : %.6g ~ %.6g deg\n', min(theta_deg), max(theta_deg));
fprintf('phi range        : %.6g ~ %.6g deg\n', min(phi_deg), max(phi_deg));
fprintf('RCS min          : %.6g %s\n', min(y), unitMode);
fprintf('RCS max          : %.6g %s\n', max(y), unitMode);
fprintf('RCS mean         : %.6g %s\n', mean(y), unitMode);
fprintf('RCS std          : %.6g %s\n', std(y), unitMode);

fprintf('RCS mean in dBsm : %.6f dBsm\n', mean(RCS_dBsm));
fprintf('RCS mean in m^2  : %.6f m^2\n', mean(RCS_linear));
fprintf('Sphere reference : %.6f dBsm / %.6f m^2\n', 10*log10(pi), pi);
fprintf('-----------------------------------\n');

% ------------------------------------------------------------
% 7. Return table
% -------------------------------------------------------------
T = table(theta_deg(:), phi_deg(:), RCS_dBsm(:), RCS_linear(:), ...
    'VariableNames', {'Theta_deg','Phi_deg','RCS_dBsm','RCS_m2'});

end

%% ============================================================
% Helper: find result variable in base workspace
% =============================================================
function result = find_result_in_base()

candidateNames = { ...
    'result_PO_old', ...
    'result_PO', ...
    'result', ...
    'result_theta', ...
    'result_originalStyle', ...
    'result_sphere_originalMAT', ...
    'result_pofacets_sphere'};

for i = 1:numel(candidateNames)
    name = candidateNames{i};

    if evalin('base', sprintf('exist(''%s'', ''var'')', name))
        result = evalin('base', name);
        fprintf('Using result variable from base workspace: %s\n', name);
        return;
    end
end

error('No result structure found in base workspace. Pass result explicitly.');

end

%% ============================================================
% Helper: extract theta and phi
% =============================================================
function [theta_deg, phi_deg] = extract_angles(result)

theta_deg = [];
phi_deg = [];

if isfield(result, 'theta')
    theta_deg = result.theta;
elseif isfield(result, 'theta_deg')
    theta_deg = result.theta_deg;
elseif isfield(result, 'cfg') && isfield(result.cfg, 'theta_deg')
    theta_deg = result.cfg.theta_deg;
elseif isfield(result, 'cfg') && isfield(result.cfg, 'tstart')
    theta_deg = result.cfg.tstart:result.cfg.delt:result.cfg.tstop;
end

if isfield(result, 'phi')
    phi_deg = result.phi;
elseif isfield(result, 'phi_deg')
    phi_deg = result.phi_deg;
elseif isfield(result, 'cfg') && isfield(result.cfg, 'phi_deg')
    phi_deg = result.cfg.phi_deg;
elseif isfield(result, 'cfg') && isfield(result.cfg, 'pstart')
    phi_deg = result.cfg.pstart:result.cfg.delp:result.cfg.pstop;
end

if isempty(theta_deg)
    theta_deg = 0;
end

if isempty(phi_deg)
    phi_deg = 0;
end

theta_deg = double(theta_deg(:));
phi_deg   = double(phi_deg(:));

end

%% ============================================================
% Helper: reshape angle vector to result length
% =============================================================
function a = reshape_angle_vector(a, nCase)

a = double(a(:));

if numel(a) == nCase
    return;
elseif numel(a) == 1
    a = repmat(a, nCase, 1);
else
    % If size does not match, use case index-like padding.
    warning('Angle vector length does not match RCS length. Resizing by interpolation index.');
    a = linspace(a(1), a(end), nCase).';
end

end

%% ============================================================
% Helper: extract RCS
% =============================================================
function [RCS_linear, RCS_dBsm, usedComponent] = extract_rcs(result, componentMode)

usedComponent = 'unknown';

% ------------------------------------------------------------
% 1. Direct co-polar fields
% -------------------------------------------------------------
if componentMode == "co" || componentMode == "auto"

    if isfield(result, 'RCSco_linear')
        RCS_linear = result.RCSco_linear(:);
        RCS_dBsm = 10*log10(RCS_linear + eps);
        usedComponent = 'RCSco_linear';
        return;
    end

    if isfield(result, 'RCSco_dBsm')
        RCS_dBsm = result.RCSco_dBsm(:);
        RCS_linear = 10.^(RCS_dBsm./10);
        usedComponent = 'RCSco_dBsm';
        return;
    end

    if isfield(result, 'RCS_dBsm')
        RCS_dBsm = result.RCS_dBsm(:);
        RCS_linear = 10.^(RCS_dBsm./10);
        usedComponent = 'RCS_dBsm';
        return;
    end

    if isfield(result, 'RCS_linear')
        RCS_linear = result.RCS_linear(:);
        RCS_dBsm = 10*log10(RCS_linear + eps);
        usedComponent = 'RCS_linear';
        return;
    end
end

% ------------------------------------------------------------
% 2. Theta component
% -------------------------------------------------------------
if componentMode == "th" || componentMode == "theta"

    if isfield(result, 'RCSth_linear')
        RCS_linear = result.RCSth_linear(:);
        RCS_dBsm = 10*log10(RCS_linear + eps);
        usedComponent = 'RCSth_linear';
        return;
    end

    if isfield(result, 'RCStheta_dBsm')
        RCS_dBsm = result.RCStheta_dBsm(:);
        RCS_linear = 10.^(RCS_dBsm./10);
        usedComponent = 'RCStheta_dBsm';
        return;
    end

    if isfield(result, 'RCSth_dBsm')
        RCS_dBsm = result.RCSth_dBsm(:);
        RCS_linear = 10.^(RCS_dBsm./10);
        usedComponent = 'RCSth_dBsm';
        return;
    end
end

% ------------------------------------------------------------
% 3. Phi component
% -------------------------------------------------------------
if componentMode == "ph" || componentMode == "phi"

    if isfield(result, 'RCSph_linear')
        RCS_linear = result.RCSph_linear(:);
        RCS_dBsm = 10*log10(RCS_linear + eps);
        usedComponent = 'RCSph_linear';
        return;
    end

    if isfield(result, 'RCSphi_dBsm')
        RCS_dBsm = result.RCSphi_dBsm(:);
        RCS_linear = 10.^(RCS_dBsm./10);
        usedComponent = 'RCSphi_dBsm';
        return;
    end

    if isfield(result, 'RCSph_dBsm')
        RCS_dBsm = result.RCSph_dBsm(:);
        RCS_linear = 10.^(RCS_dBsm./10);
        usedComponent = 'RCSph_dBsm';
        return;
    end
end

% ------------------------------------------------------------
% 4. Total theta + phi
% -------------------------------------------------------------
if componentMode == "total" || componentMode == "auto"

    if isfield(result, 'RCSth_linear') && isfield(result, 'RCSph_linear')
        RCS_linear = result.RCSth_linear(:) + result.RCSph_linear(:);
        RCS_dBsm = 10*log10(RCS_linear + eps);
        usedComponent = 'RCSth_linear + RCSph_linear';
        return;
    end
end

% ------------------------------------------------------------
% 5. Auto fallback by polarization
% -------------------------------------------------------------
pol = '';

if isfield(result, 'cfg') && isfield(result.cfg, 'pol')
    pol = char(result.cfg.pol);
end

if strcmpi(pol, 'V') || strcmpi(pol, 'theta')
    if isfield(result, 'RCSth_linear')
        RCS_linear = result.RCSth_linear(:);
        RCS_dBsm = 10*log10(RCS_linear + eps);
        usedComponent = 'auto-pol V: RCSth_linear';
        return;
    end
end

if strcmpi(pol, 'H') || strcmpi(pol, 'phi')
    if isfield(result, 'RCSph_linear')
        RCS_linear = result.RCSph_linear(:);
        RCS_dBsm = 10*log10(RCS_linear + eps);
        usedComponent = 'auto-pol H: RCSph_linear';
        return;
    end
end

% ------------------------------------------------------------
% Failed
% -------------------------------------------------------------
disp('Available result fields:');
disp(fieldnames(result));

error('Cannot find RCS field. Try componentMode = ''th'', ''ph'', or ''total''.');

end