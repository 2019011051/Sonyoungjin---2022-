function plot_apaydin_fig5_PO_Fringe_Total(result_PO, result_POPTD)
%PLOT_APAYDIN_FIG5_PO_FRINGE_TOTAL
% Plot normalized PO / Fringe / Total curves for Apaydin Fig. 5 validation.
%
% Usage:
%   load('output_fig5_PO/RCS_OUTPUT.mat')      % gives result or similar
%   result_PO = result;
%   load('output_fig5_POPTD/RCS_OUTPUT.mat')
%   result_POPTD = result;
%   plot_apaydin_fig5_PO_Fringe_Total(result_PO, result_POPTD);

    phi_deg = result_PO.phi(:);
    lambda = result_PO.wave.lambda;
    a = 2*lambda;
    b = 4*lambda;
    sigma_ref = 4*pi*a^2*b^2/lambda^2;

    PO_lin = result_PO.RCSth_linear(:);

    if nargin < 2 || isempty(result_POPTD)
        error('result_POPTD가 필요함. PO+PTD 해석 결과 구조체를 입력해야 함.');
    end

    TOT_lin = result_POPTD.RCSth_linear(:);
    FR_lin  = 4*pi*abs(result_POPTD.PTD.Ethscat(:)).^2/lambda^2;

    n = min([numel(phi_deg), numel(PO_lin), numel(FR_lin), numel(TOT_lin)]);
    phi_deg = phi_deg(1:n);
    PO_lin = PO_lin(1:n);
    FR_lin = FR_lin(1:n);
    TOT_lin = TOT_lin(1:n);

    PO_dB  = db10_local(PO_lin  ./ sigma_ref);
    FR_dB  = db10_local(FR_lin  ./ sigma_ref);
    TOT_dB = db10_local(TOT_lin ./ sigma_ref);

    figure;
    plot(phi_deg, PO_dB,  'b-',  'LineWidth', 1.5); hold on;
    plot(phi_deg, FR_dB,  'r--', 'LineWidth', 1.5);
    plot(phi_deg, TOT_dB, 'k-.', 'LineWidth', 1.8);
    grid on;
    xlabel('\phi_0 [deg]');
    ylabel('RCS / \lambda^2 [dB], normalized by Eq. (20)');
    title('Apaydin Fig. 5 validation: PO / Fringe / Total');
    legend('PO', 'Fringe', 'Total', 'Location', 'best');
    xlim([0 90]);
    ylim([-70 10]);

    fprintf('--- Apaydin Fig.5 plot summary ---\n');
    fprintf('lambda       : %.12g m\n', lambda);
    fprintf('sigma_ref    : %.12g\n', sigma_ref);
    fprintf('PO max       : %.6f dB\n', max(PO_dB));
    fprintf('Fringe max   : %.6f dB\n', max(FR_dB));
    fprintf('Total max    : %.6f dB\n', max(TOT_dB));
    fprintf('----------------------------------\n');
end

function y = db10_local(x)
    x = real(x);
    x(~isfinite(x) | x < 1e-300) = 1e-300;
    y = 10*log10(x);
end
