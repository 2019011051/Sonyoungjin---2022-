function plot_rcs_curve(curveFile, outputDir)
% RCS_CURVE.csv를 읽어서 Cartesian plot과 polar plot을 저장함

    if nargin < 1
        curveFile = fullfile('output','RCS_CURVE.csv');
    end

    if nargin < 2
        outputDir = 'output';
    end

    if ~exist(outputDir, 'dir')
        mkdir(outputDir);
    end

    T = readtable(curveFile);

    phi_deg = T.phi_deg;
    phi_rad = deg2rad(phi_deg);
    rcs_db  = T.selected_RCS_dBsm;

    % 1. 일반 선 그래프: RCS dBsm vs phi
    fig1 = figure('Visible','off','Color','w');
    plot(phi_deg, rcs_db, 'LineWidth', 1.5);
    grid on;
    xlabel('\phi [deg]');
    ylabel('RCS [dBsm]');
    title('Monostatic RCS Pattern');
    xlim([min(phi_deg), max(phi_deg)]);
    saveas(fig1, fullfile(outputDir,'RCS_LINE_PLOT.png'));
    close(fig1);

    % 2. polar plot: 선형 RCS 값으로 표시
    rcs_linear = 10.^(rcs_db/10);

    fig2 = figure('Visible','off','Color','w');
    polarplot(phi_rad, rcs_linear, 'LineWidth', 1.5);
    title('Monostatic RCS Polar Pattern');
    saveas(fig2, fullfile(outputDir,'RCS_POLAR_LINEAR.png'));
    close(fig2);

    % 3. polar plot: dBsm을 양수 반경으로 shift해서 표시
    % MATLAB polarplot은 음수 radius를 다루기 애매하므로 시각화용으로 shift함
    rcs_db_shift = rcs_db - min(rcs_db);

    fig3 = figure('Visible','off','Color','w');
    polarplot(phi_rad, rcs_db_shift, 'LineWidth', 1.5);
    title('Monostatic RCS Polar Pattern, shifted dB scale');
    saveas(fig3, fullfile(outputDir,'RCS_POLAR_SHIFTED_DB.png'));
    close(fig3);

    fprintf('Saved plots:\n');
    fprintf('  %s\n', fullfile(outputDir,'RCS_LINE_PLOT.png'));
    fprintf('  %s\n', fullfile(outputDir,'RCS_POLAR_LINEAR.png'));
    fprintf('  %s\n', fullfile(outputDir,'RCS_POLAR_SHIFTED_DB.png'));
end