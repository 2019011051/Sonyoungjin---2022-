function result = run_mono_po_ptd_batch(matFile, outputDir, cfgInput, edgeDataInput)
% run_mono_po_ptd_batch.m
% Project: PO+PTD RCS module development
% Description:
%   GUI 없이 PoFacets monostatic PO+PTD RCS 해석을 batch로 실행하는 파일임.
%   현재 단계에서는 PTD placeholder 구조 검증용으로 사용함.
%   cfg.usePTD=false 또는 cfg.ptdMode='placeholder'이면 E_PTD=0으로 계산되어
%   run_mono_po_batch.m의 PO-only 결과와 같아야 함.
%
% Usage:
%   result = run_mono_po_ptd_batch();
%   result = run_mono_po_ptd_batch('input/case_pofacets.mat','output_ptd');
%   result = run_mono_po_ptd_batch('input/case_pofacets.mat','output_ptd', cfg);
%   result = run_mono_po_ptd_batch('input/case_pofacets.mat','output_ptd','input/rcs_config.json');
%   result = run_mono_po_ptd_batch('input/case_pofacets.mat','output_ptd', cfg, edgeData);
%
% Required files in the same POPTD folder:
%   - run_mono_po_ptd_batch.m
%   - CalcMono_PO_PTD_core.m
%   - facetRCS.m
%   - input/case_pofacets.mat containing coord and facet
%
% Output files:
%   - output_ptd/avgrcs.txt
%   - output_ptd/maxrcs.txt
%   - output_ptd/minrcs.txt
%   - output_ptd/RCS_CURVE.csv
%   - output_ptd/RCS_RESULT.txt
%   - output_ptd/RCS_OUTPUT.mat

    % ------------------------------------------------------------------
    % 0. Path setup
    % ------------------------------------------------------------------
    thisDir = fileparts(mfilename('fullpath'));
    if isempty(thisDir)
        thisDir = pwd;
    end
    addpath(thisDir);

    if nargin < 1 || isempty(matFile)
        matFile = fullfile(thisDir, 'input', 'case_pofacets.mat');
    end
    if nargin < 2 || isempty(outputDir)
        outputDir = fullfile(thisDir, 'output_ptd');
    end
    if nargin < 3
        cfgInput = [];
    end
    if nargin < 4
        edgeDataInput = [];
    end

    if ~isfolder(outputDir)
        mkdir(outputDir);
    end

    % ------------------------------------------------------------------
    % 1. Check required code files
    % ------------------------------------------------------------------
    if exist('CalcMono_PO_PTD_core', 'file') ~= 2
        error('run_mono_po_ptd_batch:MissingFile', ...
              'CalcMono_PO_PTD_core.m 파일이 현재 폴더 또는 MATLAB path에 없음.');
    end
    if exist('facetRCS', 'file') ~= 2
        error('run_mono_po_ptd_batch:MissingFile', ...
              'facetRCS.m 파일이 현재 폴더 또는 MATLAB path에 없음.');
    end

    % ------------------------------------------------------------------
    % 2. Load PoFacets geometry model
    % ------------------------------------------------------------------
    if exist(matFile, 'file') ~= 2
        error('run_mono_po_ptd_batch:InputError', '형상 .mat 파일을 찾을 수 없음: %s', matFile);
    end

    model = load(matFile);
    if ~isfield(model, 'coord') || ~isfield(model, 'facet')
        error('run_mono_po_ptd_batch:InputError', ...
              '.mat 파일 안에 coord와 facet 변수가 모두 있어야 함.');
    end

    coord = model.coord;
    facet = model.facet;

    % ------------------------------------------------------------------
    % 3. Build analysis configuration
    % ------------------------------------------------------------------
    cfg = default_mono_po_ptd_cfg();

    if isstruct(cfgInput)
        cfg = merge_struct(cfg, cfgInput);
    elseif ischar(cfgInput) || isstring(cfgInput)
        cfgFile = char(cfgInput);
        if exist(cfgFile, 'file') ~= 2
            error('run_mono_po_ptd_batch:InputError', 'cfg 파일을 찾을 수 없음: %s', cfgFile);
        end
        cfgFromFile = jsondecode(fileread(cfgFile));
        cfg = merge_struct(cfg, cfgFromFile);
    elseif ~isempty(cfgInput)
        error('run_mono_po_ptd_batch:InputError', ...
              'cfgInput은 struct, JSON 파일 경로, 또는 빈 값이어야 함.');
    end

    % CalcMono_core 계열과 CalcMono_PO_PTD_core 계열의 주파수 필드명 호환
    if isfield(cfg, 'freq') && ~isfield(cfg, 'freqGHz')
        cfg.freqGHz = cfg.freq;
    elseif isfield(cfg, 'freqGHz') && ~isfield(cfg, 'freq')
        cfg.freq = cfg.freqGHz;
    elseif isfield(cfg, 'freq') && isfield(cfg, 'freqGHz')
        cfg.freqGHz = cfg.freq;
    end

    cfg.matFile = matFile;
    cfg.outputDir = outputDir;

    % ------------------------------------------------------------------
    % 4. Edge data input
    % ------------------------------------------------------------------
    edgeData = [];

    if ~isempty(edgeDataInput)
        edgeData = load_edge_data_input(edgeDataInput);
    elseif isfield(cfg, 'edgeData') && ~isempty(cfg.edgeData)
        edgeData = cfg.edgeData;
    elseif isfield(cfg, 'edgeDataFile') && ~isempty(cfg.edgeDataFile)
        edgeData = load_edge_data_input(cfg.edgeDataFile);
    end

    % 현재 placeholder 단계에서는 edgeData가 없어도 정상임.
    % 실제 PTD 수식 단계에서는 cfg.usePTD=true, cfg.ptdMode='external',
    % edgeData 제공이 필요함.

    % ------------------------------------------------------------------
    % 5. Run monostatic PO+PTD solver
    % ------------------------------------------------------------------
    fprintf('--- run_mono_po_ptd_batch started ---\n');
    fprintf('Model file : %s\n', matFile);
    fprintf('Output dir : %s\n', outputDir);
    fprintf('Frequency  : %.6g GHz\n', cfg.freqGHz);
    fprintf('Theta      : %.6g : %.6g : %.6g deg\n', cfg.tstart, cfg.delt, cfg.tstop);
    fprintf('Phi        : %.6g : %.6g : %.6g deg\n', cfg.pstart, cfg.delp, cfg.pstop);
    fprintf('usePTD     : %d\n', logical(cfg.usePTD));
    fprintf('ptdMode    : %s\n', char(cfg.ptdMode));

    result = CalcMono_PO_PTD_core(coord, facet, cfg, edgeData);

    % ------------------------------------------------------------------
    % 6. Export results for PIAnO/RCE and post-processing
    % ------------------------------------------------------------------
    export_batch_results_ptd(result, outputDir);

    fprintf('RCS_avg    : %.10g dBsm\n', result.metrics.RCS_avg_dBsm);
    fprintf('RCS_max    : %.10g dBsm\n', result.metrics.RCS_max_dBsm);
    fprintf('RCS_min    : %.10g dBsm\n', result.metrics.RCS_min_dBsm);

    if isfield(result, 'PTD')
        fprintf('PTD_Etheta_max_abs : %.10g\n', result.metrics.PTD_Etheta_max_abs);
        fprintf('PTD_Ephi_max_abs   : %.10g\n', result.metrics.PTD_Ephi_max_abs);
    end

    fprintf('--- run_mono_po_ptd_batch finished ---\n');

end

% -------------------------------------------------------------------------
function cfg = default_mono_po_ptd_cfg()
%DEFAULT_MONO_PO_PTD_CFG 초기 PO+PTD monostatic RCS 해석 기본값임.
% PoFacets 좌표계 기준: theta=90 deg 고정, phi=0~360 deg sweep.

    cfg = struct();
    cfg.C = 299792458;

    % CalcMono_PO_PTD_core는 freqGHz를 사용함.
    % 기존 run_mono_po_batch와 비교 편의를 위해 freq도 같이 둠.
    cfg.freqGHz = 10;
    cfg.freq = 10;

    % Horizontal azimuth sweep in PoFacets convention.
    cfg.tstart = 90;
    cfg.tstop  = 90;
    cfg.delt   = 1;

    cfg.pstart = 0;
    cfg.pstop  = 360;
    cfg.delp   = 1;

    % 1: theta-pol, 2: phi-pol
    cfg.i_pol = 1;

    % Free-space, PEC/Rs based, no roughness/diffuse correction.
    cfg.rsmethod = 1;
    cfg.iflag = 0;
    cfg.corr = 0;
    cfg.std = 0;
    cfg.Nt = 10;
    cfg.Lt = 0.01;
    cfg.useground = 0;
    cfg.usesymmetry = 0;
    cfg.clipFloor = false;

    % PTD placeholder settings.
    % 현재 검증 단계에서는 E_PTD=0이어야 함.
    cfg.usePTD = false;
    cfg.ptdMode = 'placeholder';
    cfg.edgeDataFile = '';

end

% -------------------------------------------------------------------------
function s = merge_struct(s, u)
%MERGE_STRUCT u에 있는 field로 s의 field를 덮어씀.
    if isempty(u)
        return;
    end
    names = fieldnames(u);
    for k = 1:numel(names)
        s.(names{k}) = u.(names{k});
    end
end

% -------------------------------------------------------------------------
function edgeData = load_edge_data_input(edgeDataInput)
%LOAD_EDGE_DATA_INPUT edgeData 구조체 또는 .mat 파일을 읽음.

    if isstruct(edgeDataInput)
        edgeData = edgeDataInput;
        return;
    end

    if ischar(edgeDataInput) || isstring(edgeDataInput)
        edgeFile = char(edgeDataInput);
        if exist(edgeFile, 'file') ~= 2
            error('run_mono_po_ptd_batch:InputError', ...
                  'edgeData 파일을 찾을 수 없음: %s', edgeFile);
        end

        loaded = load(edgeFile);
        if isfield(loaded, 'edgeData')
            edgeData = loaded.edgeData;
        else
            % 파일 안에 edgeData라는 이름이 없으면 전체 load 결과를 전달함.
            edgeData = loaded;
        end
        return;
    end

    error('run_mono_po_ptd_batch:InputError', ...
          'edgeDataInput은 struct 또는 .mat 파일 경로여야 함.');
end

% -------------------------------------------------------------------------
function export_batch_results_ptd(result, outputDir)
%EXPORT_BATCH_RESULTS_PTD RCS 결과를 txt/csv/mat로 저장함.

    avgrcsFile = fullfile(outputDir, 'avgrcs.txt');
    maxrcsFile = fullfile(outputDir, 'maxrcs.txt');
    minrcsFile = fullfile(outputDir, 'minrcs.txt');
    curveFile  = fullfile(outputDir, 'RCS_CURVE.csv');
    resultFile = fullfile(outputDir, 'RCS_RESULT.txt');
    matOutFile = fullfile(outputDir, 'RCS_OUTPUT.mat');

    % PIAnO/RCE가 숫자만 읽기 쉽도록 txt에는 숫자만 저장함.
    write_scalar_txt(avgrcsFile, result.metrics.RCS_avg_dBsm);
    write_scalar_txt(maxrcsFile, result.metrics.RCS_max_dBsm);
    write_scalar_txt(minrcsFile, result.metrics.RCS_min_dBsm);

    % Angle-wise curve export.
    phiCol   = result.phi(:);
    thetaCol = result.theta(:);
    SthCol   = result.Sth_raw(:);
    SphCol   = result.Sph_raw(:);

    if strcmpi(result.metrics.selected_pol, 'theta')
        selectedCol = SthCol;
    else
        selectedCol = SphCol;
    end

    % PO/PTD field magnitude도 디버깅용으로 저장함.
    EthPOAbs  = abs(result.PO.Ethscat(:));
    EphPOAbs  = abs(result.PO.Ephscat(:));
    EthPTDAbs = abs(result.PTD.Ethscat(:));
    EphPTDAbs = abs(result.PTD.Ephscat(:));

    T = table(thetaCol, phiCol, SthCol, SphCol, selectedCol, ...
              EthPOAbs, EphPOAbs, EthPTDAbs, EphPTDAbs, ...
        'VariableNames', {'theta_deg','phi_deg','Sth_dBsm','Sph_dBsm','selected_RCS_dBsm', ...
                          'abs_Etheta_PO','abs_Ephi_PO','abs_Etheta_PTD','abs_Ephi_PTD'});
    writetable(T, curveFile);

    % Human-readable summary.
    fid = fopen(resultFile, 'w');
    if fid < 0
        error('run_mono_po_ptd_batch:OutputError', '결과 파일을 열 수 없음: %s', resultFile);
    end
    cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>

    fprintf(fid, 'PO+PTD monostatic RCS batch result\n');
    fprintf(fid, 'selected_pol : %s\n', result.metrics.selected_pol);
    fprintf(fid, 'usePTD       : %d\n', logical(result.cfg.usePTD));
    fprintf(fid, 'ptdMode      : %s\n', char(result.cfg.ptdMode));
    fprintf(fid, 'freq_GHz     : %.12g\n', result.wave.freqGHz);
    fprintf(fid, 'lambda_m     : %.12g\n', result.wave.lambda);

    if isfield(result, 'mesh') && isfield(result.mesh, 'nvert')
        fprintf(fid, 'nvert        : %d\n', result.mesh.nvert);
    else
        fprintf(fid, 'nvert        : N/A\n');
    end

    if isfield(result, 'mesh') && isfield(result.mesh, 'ntria')
        fprintf(fid, 'ntria        : %d\n', result.mesh.ntria);
    else
        fprintf(fid, 'ntria        : N/A\n');
    end

    fprintf(fid, 'theta_start  : %.12g\n', result.cfg.tstart);
    fprintf(fid, 'theta_stop   : %.12g\n', result.cfg.tstop);
    fprintf(fid, 'theta_step   : %.12g\n', result.cfg.delt);
    fprintf(fid, 'phi_start    : %.12g\n', result.cfg.pstart);
    fprintf(fid, 'phi_stop     : %.12g\n', result.cfg.pstop);
    fprintf(fid, 'phi_step     : %.12g\n', result.cfg.delp);
    fprintf(fid, 'RCS_avg_dBsm : %.12g\n', result.metrics.RCS_avg_dBsm);
    fprintf(fid, 'RCS_max_dBsm : %.12g\n', result.metrics.RCS_max_dBsm);
    fprintf(fid, 'RCS_min_dBsm : %.12g\n', result.metrics.RCS_min_dBsm);

    if isfield(result.metrics, 'PTD_Etheta_max_abs')
        fprintf(fid, 'PTD_Etheta_max_abs : %.12g\n', result.metrics.PTD_Etheta_max_abs);
    end
    if isfield(result.metrics, 'PTD_Ephi_max_abs')
        fprintf(fid, 'PTD_Ephi_max_abs   : %.12g\n', result.metrics.PTD_Ephi_max_abs);
    end

    save(matOutFile, 'result');
end

% -------------------------------------------------------------------------
function write_scalar_txt(fileName, value)
%WRITE_SCALAR_TXT 숫자 하나만 저장함.
    fid = fopen(fileName, 'w');
    if fid < 0
        error('run_mono_po_ptd_batch:OutputError', '파일을 열 수 없음: %s', fileName);
    end
    cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
    fprintf(fid, '%.12g\n', value);
end
