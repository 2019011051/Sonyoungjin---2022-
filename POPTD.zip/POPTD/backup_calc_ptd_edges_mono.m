function [Eptd_t, Eptd_p, ptdInfo] = calc_ptd_edges_mono(edgeData, ptdCtx, cfg)


    % ---------------------------------------------------------------
    % 0. Default outputs
    % ---------------------------------------------------------------
    Eptd_t = complex(0,0);
    Eptd_p = complex(0,0);

    ptdInfo = struct();
    ptdInfo.version = 'michaeli_backscatter_original_like_no_guard_2026_06_01';
    ptdInfo.status = 'placeholder_zero';
    ptdInfo.message = 'E_PTD = 0. PTD equation is not implemented yet.';
    ptdInfo.nEdgesTotal = 0;
    ptdInfo.nEdgesUsed = 0;
    ptdInfo.selectedEdgeIdx = [];

    % ---------------------------------------------------------------
    % 1. Basic input check
    % ---------------------------------------------------------------
    if nargin < 1 || isempty(edgeData)
        ptdInfo.status = 'no_edgeData';
        ptdInfo.message = 'edgeData is empty. E_PTD = 0.';
        return;
    end

    if nargin < 2 || isempty(ptdCtx)
        ptdCtx = struct();
    end

    if nargin < 3 || isempty(cfg)
        cfg = struct();
    end

    requiredFields = {'p1','p2','center','length','tangent','usePTD'};
    for ii = 1:numel(requiredFields)
        f = requiredFields{ii};
        if ~isfield(edgeData, f)
            ptdInfo.status = 'invalid_edgeData';
            ptdInfo.message = sprintf('edgeData.%s field is missing. E_PTD = 0.', f);
            return;
        end
    end

    nEdges = numel(edgeData.length);
    ptdInfo.nEdgesTotal = nEdges;

    % ---------------------------------------------------------------
    % 2. Select PTD edges
    % ---------------------------------------------------------------
    usePTD = logical(edgeData.usePTD(:));

    minLen = getfield_default(cfg, 'ptdMinEdgeLength', 0);
    validLength = edgeData.length(:) > minLen & isfinite(edgeData.length(:));

    selectedEdgeIdx = find(usePTD & validLength);

    maxEdges = getfield_default(cfg, 'ptdMaxEdges', inf);
    if isfinite(maxEdges) && maxEdges > 0 && numel(selectedEdgeIdx) > maxEdges
        selectedEdgeIdx = selectedEdgeIdx(1:maxEdges);
    end

    ptdInfo.nEdgesUsed = numel(selectedEdgeIdx);
    ptdInfo.selectedEdgeIdx = selectedEdgeIdx;

    if isempty(selectedEdgeIdx)
        ptdInfo.status = 'no_selected_edges';
        ptdInfo.message = 'No edge has usePTD=true. E_PTD = 0.';
        return;
    end

    % ---------------------------------------------------------------
    % 3. Basic wave and direction information
    % ---------------------------------------------------------------
    ptdFormula = char(getfield_default(cfg, 'ptdFormula', 'placeholder'));
    ptdDebug = logical(getfield_default(cfg, 'ptdDebug', false));

    ptdInfo.ptdFormula = ptdFormula;
    ptdInfo.theta_deg = getfield_default(ptdCtx, 'theta_deg', NaN);
    ptdInfo.phi_deg = getfield_default(ptdCtx, 'phi_deg', NaN);
    ptdInfo.lambda_m = getfield_default(ptdCtx, 'wave', NaN);
    ptdInfo.k = getfield_default(ptdCtx, 'k', NaN);

    Rhat = getfield_default(ptdCtx, 'direction', [NaN NaN NaN]);
    Rhat = normalize_row(Rhat);

    % Monostatic convention:
    %   Rhat  : target -> radar observation direction
    %   KiHat : incident propagation direction, radar -> target
    %   KsHat : scattered observation direction, target -> radar
    KsHat = Rhat;
    KiHat = -Rhat;

    Einc = getfield_default(ptdCtx, 'e0', [1 0 0]);
    Einc = reshape(Einc, 1, []);
    if numel(Einc) ~= 3 || any(~isfinite(Einc))
        Einc = [1 0 0];
    end

    eta0 = getfield_default(cfg, 'eta0', 376.730313668);
    Hinc = cross(KiHat, Einc) / eta0;

    ptdInfo.Rhat = Rhat;
    ptdInfo.KiHat = KiHat;
    ptdInfo.KsHat = KsHat;
    ptdInfo.Einc = Einc;
    ptdInfo.Hinc = Hinc;
    ptdInfo.eta0 = eta0;

    % ---------------------------------------------------------------
    % 4. Formula mode control
    % ---------------------------------------------------------------
    switch lower(ptdFormula)

        case {'test_nonzero','debug_nonzero'}
            amp = getfield_default(cfg, 'ptdTestAmp', 1e-3);

            k = ptdInfo.k;
            if ~isfinite(k) || k == 0
                k = 1;
            end

            centers = edgeData.center(selectedEdgeIdx, :);
            lens    = edgeData.length(selectedEdgeIdx);

            totalLen = sum(lens);
            if totalLen <= 0 || ~isfinite(totalLen)
                totalLen = 1;
            end

            phaseArg = centers * KsHat(:);
            phaseTerm = exp(-1i * k * phaseArg);

            weight = lens(:) ./ totalLen;

            Eptd_t = amp * sum(weight .* phaseTerm);
            Eptd_p = complex(0,0);

            ptdInfo.status = 'test_nonzero';
            ptdInfo.message = 'Non-physical test mode. E_PTD is artificially non-zero.';
            ptdInfo.testAmp = amp;
            ptdInfo.test_Eptd_t_abs = abs(Eptd_t);
            ptdInfo.test_Eptd_p_abs = abs(Eptd_p);

            if ptdDebug
                fprintf('--- calc_ptd_edges_mono test_nonzero summary ---\n');
                fprintf('selected edges      : %d\n', numel(selectedEdgeIdx));
                fprintf('ptdTestAmp          : %.6g\n', amp);
                fprintf('|Eptd_t|            : %.6g\n', abs(Eptd_t));
                fprintf('|Eptd_p|            : %.6g\n', abs(Eptd_p));
                fprintf('-----------------------------------------------\n');
            end
            return;

        case {'placeholder','zero','none'}
            Eptd_t = complex(0,0);
            Eptd_p = complex(0,0);
            ptdInfo.status = 'placeholder_zero';
            ptdInfo.message = 'Placeholder mode. E_PTD = 0.';
            return;

        case {'inspect','inspect_inputs','michaeli_inputs'}
            ptdInfo = inspect_edge_local_inputs(edgeData, selectedEdgeIdx, KiHat, KsHat, Einc, Hinc, ptdInfo, cfg);
            Eptd_t = complex(0,0);
            Eptd_p = complex(0,0);
            ptdInfo.status = 'inspect_only';
            ptdInfo.message = 'Inspect mode. Michaeli input variables were computed. E_PTD = 0.';

            if ptdDebug
                print_inspect_summary(ptdInfo);
            end
            return;

        case {'michaeli_backscatter','michaeli_back'}
            [Eptd_t, Eptd_p, ptdInfo] = run_michaeli_backscatter_edges( ...
                edgeData, selectedEdgeIdx, KiHat, KsHat, Rhat, Einc, Hinc, ptdInfo, cfg);

            ptdInfo.status = 'michaeli_backscatter';
            ptdInfo.message = 'Michaeli backscatter PTD equivalent edge current was applied.';

            if ptdDebug
                print_michaeli_backscatter_summary(ptdInfo);
            end
            return;

        otherwise
            Eptd_t = complex(0,0);
            Eptd_p = complex(0,0);
            ptdInfo.status = 'formula_not_implemented';
            ptdInfo.message = sprintf('PTD formula "%s" is not implemented yet. E_PTD = 0.', ptdFormula);
            return;
    end
end

% =====================================================================
function ptdInfo = inspect_edge_local_inputs(edgeData, selectedEdgeIdx, KiHat, KsHat, Einc, Hinc, ptdInfo, cfg)

    nSel = numel(selectedEdgeIdx);
    storeMax = getfield_default(cfg, 'ptdInspectStoreMax', min(nSel, 100));
    storeMax = min(storeMax, nSel);

    beta_i_deg = nan(nSel,1);
    beta_s_deg = nan(nSel,1);
    phi_i_deg  = nan(nSel,1);
    phi_s_deg  = nan(nSel,1);
    e_edge     = nan(nSel,1);
    h_edge     = nan(nSel,1);
    wedge_deg  = nan(nSel,1);
    edge_len   = nan(nSel,1);
    localOK    = false(nSel,1);
    failReason = cell(nSel,1);

    xhat_store = nan(storeMax,3);
    yhat_store = nan(storeMax,3);
    zhat_store = nan(storeMax,3);

    hasNormal1 = isfield(edgeData, 'normal1');
    hasNormal2 = isfield(edgeData, 'normal2');
    hasWedge = isfield(edgeData, 'wedgeInterior_deg');

    for jj = 1:nSel
        eidx = selectedEdgeIdx(jj);
        edge_len(jj) = edgeData.length(eidx);

        t = edgeData.tangent(eidx,:);
        t = normalize_row(t);
        if any(~isfinite(t)) || norm(t) < eps
            failReason{jj} = 'invalid_tangent';
            continue;
        end

        if hasNormal1
            n1 = edgeData.normal1(eidx,:);
        else
            n1 = [NaN NaN NaN];
        end

        if hasNormal2
            n2 = edgeData.normal2(eidx,:);
        else
            n2 = [NaN NaN NaN];
        end

        yhat = n1;
        if any(~isfinite(yhat)) || norm(yhat) < eps
            yhat = n2;
        end
        if any(~isfinite(yhat)) || norm(yhat) < eps
            failReason{jj} = 'invalid_adjacent_normal';
            continue;
        end

        yhat = yhat - dot(yhat, t)*t;
        yhat = normalize_row(yhat);
        if any(~isfinite(yhat)) || norm(yhat) < eps
            failReason{jj} = 'normal_parallel_to_tangent';
            continue;
        end

        zhat = t;
        xhat = cross(yhat, zhat);
        xhat = normalize_row(xhat);
        if any(~isfinite(xhat)) || norm(xhat) < eps
            failReason{jj} = 'invalid_xhat';
            continue;
        end

        yhat = cross(zhat, xhat);
        yhat = normalize_row(yhat);

        Ki_local = [dot(KiHat,xhat), dot(KiHat,yhat), dot(KiHat,zhat)];
        Ks_local = [dot(KsHat,xhat), dot(KsHat,yhat), dot(KsHat,zhat)];

        beta_i_deg(jj) = acosd(clamp_scalar(dot(KiHat, zhat), -1, 1));
        beta_s_deg(jj) = acosd(clamp_scalar(dot(KsHat, zhat), -1, 1));

        phi_i_deg(jj) = mod(atan2d(Ki_local(2), Ki_local(1)), 360);
        phi_s_deg(jj) = mod(atan2d(Ks_local(2), Ks_local(1)), 360);

        e_edge(jj) = sum(Einc .* zhat);
        h_edge(jj) = sum(Hinc .* zhat);

        if hasWedge
            wedge_deg(jj) = edgeData.wedgeInterior_deg(eidx);
        end

        localOK(jj) = true;
        failReason{jj} = 'ok';

        if jj <= storeMax
            xhat_store(jj,:) = xhat;
            yhat_store(jj,:) = yhat;
            zhat_store(jj,:) = zhat;
        end
    end

    ptdInfo.inspect = struct();
    ptdInfo.inspect.nSelected = nSel;
    ptdInfo.inspect.nLocalOK = nnz(localOK);
    ptdInfo.inspect.nLocalFail = nnz(~localOK);
    ptdInfo.inspect.beta_i_deg = beta_i_deg;
    ptdInfo.inspect.beta_s_deg = beta_s_deg;
    ptdInfo.inspect.phi_i_deg = phi_i_deg;
    ptdInfo.inspect.phi_s_deg = phi_s_deg;
    ptdInfo.inspect.E_edge = e_edge;
    ptdInfo.inspect.H_edge = h_edge;
    ptdInfo.inspect.wedgeInterior_deg = wedge_deg;
    ptdInfo.inspect.edgeLength = edge_len;
    ptdInfo.inspect.localOK = localOK;
    ptdInfo.inspect.failReason = failReason;
    ptdInfo.inspect.xhat_sample = xhat_store;
    ptdInfo.inspect.yhat_sample = yhat_store;
    ptdInfo.inspect.zhat_sample = zhat_store;

    ok = localOK & isfinite(beta_i_deg) & isfinite(beta_s_deg) & isfinite(phi_i_deg) & isfinite(phi_s_deg);
    ptdInfo.inspect.okForAngleStats = ok;

    if any(ok)
        ptdInfo.inspect.beta_i_range_deg = [min(beta_i_deg(ok)), max(beta_i_deg(ok))];
        ptdInfo.inspect.beta_s_range_deg = [min(beta_s_deg(ok)), max(beta_s_deg(ok))];
        ptdInfo.inspect.phi_i_range_deg = [min(phi_i_deg(ok)), max(phi_i_deg(ok))];
        ptdInfo.inspect.phi_s_range_deg = [min(phi_s_deg(ok)), max(phi_s_deg(ok))];
    else
        ptdInfo.inspect.beta_i_range_deg = [NaN NaN];
        ptdInfo.inspect.beta_s_range_deg = [NaN NaN];
        ptdInfo.inspect.phi_i_range_deg = [NaN NaN];
        ptdInfo.inspect.phi_s_range_deg = [NaN NaN];
    end
end

% =====================================================================
function [Eptd_t, Eptd_p, ptdInfo] = run_michaeli_backscatter_edges( ...
    edgeData, selectedEdgeIdx, KiHat, KsHat, Rhat, Einc, Hinc, ptdInfo, cfg)

    Eptd_t = complex(0,0);
    Eptd_p = complex(0,0);

    eta0 = getfield_default(cfg, 'eta0', 376.730313668);
    Y0   = 1 / eta0;

    k = ptdInfo.k;
    if ~isfinite(k) || k <= 0
        k = getfield_default(cfg, 'kFallback', 1);
    end

    scale = getfield_default(cfg, 'ptdScale', 1.0);
    epsSing = getfield_default(cfg, 'ptdSingularityEps', 1e-6);
    [thetaHat, phiHat] = make_spherical_basis_from_angles( ...
        ptdInfo.theta_deg, ptdInfo.phi_deg, Rhat);

    nSel = numel(selectedEdgeIdx);

    nUsed = 0;
    nSkipped = 0;

    Iabs = nan(nSel,1);
    Mabs = nan(nSel,1);
    betaPrimeDeg = nan(nSel,1);
    phiBackDeg = nan(nSel,1);
    Nval = nan(nSel,1);

    for jj = 1:nSel
        eidx = selectedEdgeIdx(jj);

        t = normalize_row(edgeData.tangent(eidx,:));
        if any(~isfinite(t))
            nSkipped = nSkipped + 1;
            continue;
        end

        n1 = get_edge_row(edgeData, 'normal1', eidx);
        n2 = get_edge_row(edgeData, 'normal2', eidx);

        [xhat, yhat, zhat, okLocal] = make_edge_local_frame(t, n1, n2);
        if ~okLocal
            nSkipped = nSkipped + 1;
            continue;
        end

        if isfield(edgeData, 'wedgeExterior_deg')
            wedgeExteriorDeg = edgeData.wedgeExterior_deg(eidx);
        elseif isfield(edgeData, 'wedgeInterior_deg')
            wedgeExteriorDeg = 360 - edgeData.wedgeInterior_deg(eidx);
        else
            wedgeExteriorDeg = 270;
        end

        if ~isfinite(wedgeExteriorDeg) || wedgeExteriorDeg <= 0
            nSkipped = nSkipped + 1;
            continue;
        end

        wedgeExteriorRad = deg2rad(wedgeExteriorDeg);
        N = wedgeExteriorRad / pi;

        if ~isfinite(N) || N <= 0
            nSkipped = nSkipped + 1;
            continue;
        end

        Ki_local = [dot(KiHat,xhat), dot(KiHat,yhat), dot(KiHat,zhat)];

        betaPrime = acos(clamp_scalar(dot(KiHat, zhat), -1, 1));
        sinBeta = sin(betaPrime);

        if abs(sinBeta) < epsSing
            nSkipped = nSkipped + 1;
            continue;
        end

        phiBack = atan2(Ki_local(2), Ki_local(1));
        phiBack = wrap_to_0_2pi(phiBack);

        phiBack = mod(phiBack, N*pi);

        if abs(sin(phiBack)) < epsSing
            phiBack = phiBack + epsSing;
        end

        Ez_i = sum(Einc .* zhat);
        Hz_i = sum(Hinc .* zhat);

        [Iback, Mback, okCur] = compute_michaeli_backscatter_currents( ...
            Ez_i, Hz_i, betaPrime, phiBack, N, k, eta0, Y0, epsSing);

        if ~okCur
            nSkipped = nSkipped + 1;
            continue;
        end

        center = edgeData.center(eidx,:);
        Ledge  = edgeData.length(eidx);

        if any(~isfinite(center)) || ~isfinite(Ledge) || Ledge <= 0
            nSkipped = nSkipped + 1;
            continue;
        end

        phaseTerm = exp(1i * 2 * k * dot(center, Rhat));

        vecI = cross(KsHat, cross(KsHat, zhat));
        vecM = cross(KsHat, zhat);

        Evec = -1i * k * Ledge * phaseTerm * ...
            (eta0 * Iback * vecI + Mback * vecM);

        Evec = scale * Evec;

        Eptd_t = Eptd_t + sum(Evec .* thetaHat);
        Eptd_p = Eptd_p + sum(Evec .* phiHat);

        nUsed = nUsed + 1;

        Iabs(jj) = abs(Iback);
        Mabs(jj) = abs(Mback);
        betaPrimeDeg(jj) = rad2deg(betaPrime);
        phiBackDeg(jj) = rad2deg(phiBack);
        Nval(jj) = N;
    end

    ptdInfo.michaeli = struct();
    ptdInfo.michaeli.nSelected = nSel;
    ptdInfo.michaeli.nUsed = nUsed;
    ptdInfo.michaeli.nSkipped = nSkipped;
    ptdInfo.michaeli.Iback_abs_max = max_abs_finite(Iabs);
    ptdInfo.michaeli.Mback_abs_max = max_abs_finite(Mabs);
    ptdInfo.michaeli.betaPrime_range_deg = finite_range(betaPrimeDeg);
    ptdInfo.michaeli.phiBack_range_deg = finite_range(phiBackDeg);
    ptdInfo.michaeli.N_range = finite_range(Nval);
    ptdInfo.michaeli.Eptd_t_abs = abs(Eptd_t);
    ptdInfo.michaeli.Eptd_p_abs = abs(Eptd_p);
    ptdInfo.michaeli.ptdScale = scale;
end

% =====================================================================
function [Iback, Mback, ok] = compute_michaeli_backscatter_currents( ...
    Ez_i, Hz_i, betaPrime, phi, N, k, Z0, Y0, epsSing)

    ok = true;
    Iback = complex(0,0);
    Mback = complex(0,0);

    if any(~isfinite([Ez_i, Hz_i, betaPrime, phi, N, k])) || N <= 0 || k <= 0
        ok = false;
        return;
    end

    sinB = sin(betaPrime);
    if abs(sinB) < epsSing
        ok = false;
        return;
    end

    cPiN = cos(pi / N);
    sPiN = sin(pi / N);

    d0 = safe_den(cPiN - 1, epsSing);
    d1 = safe_den(cPiN - cos(2 * phi / N), epsSing);

    Mcoef = (2i * Z0 * sPiN) / (N * k * sinB^2);
    Mback = Hz_i * Mcoef * (1/d0 + 1/d1);

    Icoef_E = (2i * Y0 * sPiN) / (N * k * sinB^2);
    I_E = Ez_i * Icoef_E * (1/d0 - 1/d1);

    termA_num = cot_safe(phi, epsSing) * sin((pi - phi) / N);
    termA_den = safe_den(cos((pi - phi) / N) - cos(phi / N), epsSing);
    termA = termA_num / termA_den;

    termB_num = cot_safe(N*pi - phi, epsSing) * sin((pi + phi) / N);
    termB_den = safe_den(cos((pi + phi) / N) - cos(phi / N), epsSing);
    termB = termB_num / termB_den;

    curly = termA - termB;

    Icoef_H = (4i * cot_safe(betaPrime, epsSing)) / (N * k * sinB);
    I_H = -Hz_i * Icoef_H * curly;

    Iback = I_E + I_H;

    if ~isfinite(real(Iback)) || ~isfinite(imag(Iback)) || ...
       ~isfinite(real(Mback)) || ~isfinite(imag(Mback))
        ok = false;
    end
end

% =====================================================================
function print_inspect_summary(ptdInfo)

    I = ptdInfo.inspect;
    fprintf('--- calc_ptd_edges_mono inspect summary ---\n');
    fprintf('version         : %s\n', ptdInfo.version);
    fprintf('theta, phi      : %.6g, %.6g deg\n', ptdInfo.theta_deg, ptdInfo.phi_deg);
    fprintf('selected edges  : %d\n', I.nSelected);
    fprintf('local OK / fail : %d / %d\n', I.nLocalOK, I.nLocalFail);
    fprintf('beta_i range    : %s deg\n', range_to_string(I.beta_i_range_deg));
    fprintf('beta_s range    : %s deg\n', range_to_string(I.beta_s_range_deg));
    fprintf('phi_i range     : %s deg\n', range_to_string(I.phi_i_range_deg));
    fprintf('phi_s range     : %s deg\n', range_to_string(I.phi_s_range_deg));
    fprintf('E_edge abs max  : %.6g\n', max_abs_finite(I.E_edge));
    fprintf('H_edge abs max  : %.6g\n', max_abs_finite(I.H_edge));
    fprintf('------------------------------------------\n');
end

% =====================================================================
function print_michaeli_backscatter_summary(ptdInfo)

    M = ptdInfo.michaeli;

    fprintf('--- calc_ptd_edges_mono michaeli_backscatter summary ---\n');
    fprintf('selected edges       : %d\n', M.nSelected);
    fprintf('used / skipped       : %d / %d\n', M.nUsed, M.nSkipped);
    fprintf('N range              : %s\n', range_to_string(M.N_range));
    fprintf('betaPrime range      : %s deg\n', range_to_string(M.betaPrime_range_deg));
    fprintf('phiBack range        : %s deg\n', range_to_string(M.phiBack_range_deg));
    fprintf('Iback abs max        : %.6g\n', M.Iback_abs_max);
    fprintf('Mback abs max        : %.6g\n', M.Mback_abs_max);
    fprintf('|Eptd_t|             : %.6g\n', M.Eptd_t_abs);
    fprintf('|Eptd_p|             : %.6g\n', M.Eptd_p_abs);
    fprintf('ptdScale             : %.6g\n', M.ptdScale);
    fprintf('---------------------------------------------------------\n');
end

% =====================================================================
function [xhat, yhat, zhat, ok] = make_edge_local_frame(t, n1, n2)

    ok = false;

    zhat = normalize_row(t);
    if any(~isfinite(zhat))
        xhat = [NaN NaN NaN];
        yhat = [NaN NaN NaN];
        return;
    end

    yhat = normalize_row(n1);
    if any(~isfinite(yhat))
        yhat = normalize_row(n2);
    end

    if any(~isfinite(yhat))
        xhat = [NaN NaN NaN];
        yhat = [NaN NaN NaN];
        return;
    end

    yhat = yhat - dot(yhat, zhat) * zhat;
    yhat = normalize_row(yhat);

    if any(~isfinite(yhat))
        xhat = [NaN NaN NaN];
        return;
    end

    xhat = cross(yhat, zhat);
    xhat = normalize_row(xhat);

    if any(~isfinite(xhat))
        return;
    end

    yhat = cross(zhat, xhat);
    yhat = normalize_row(yhat);

    ok = all(isfinite([xhat yhat zhat]));
end

% =====================================================================
function [thetaHat, phiHat] = make_spherical_basis_from_angles(thetaDeg, phiDeg, Rhat)

    if isfinite(thetaDeg) && isfinite(phiDeg)
        th = deg2rad(thetaDeg);
        ph = deg2rad(phiDeg);

        thetaHat = [cos(th)*cos(ph), cos(th)*sin(ph), -sin(th)];
        phiHat   = [-sin(ph), cos(ph), 0];

        thetaHat = normalize_row(thetaHat);
        phiHat   = normalize_row(phiHat);
        return;
    end

    z0 = [0 0 1];
    phiHat = cross(z0, Rhat);
    phiHat = normalize_row(phiHat);

    if any(~isfinite(phiHat))
        phiHat = [0 1 0];
    end

    thetaHat = cross(phiHat, Rhat);
    thetaHat = normalize_row(thetaHat);
end

% =====================================================================
function row = get_edge_row(edgeData, fieldName, idx)

    if isfield(edgeData, fieldName)
        row = edgeData.(fieldName)(idx,:);
    else
        row = [NaN NaN NaN];
    end
end

% =====================================================================
function m = max_abs_finite(v)

    v = v(:);
    v = abs(v(isfinite(v)));
    if isempty(v)
        m = NaN;
    else
        m = max(v);
    end
end

% =====================================================================
function s = range_to_string(v)

    if numel(v) ~= 2 || any(~isfinite(v))
        s = '[NaN, NaN]';
    else
        s = sprintf('[%.6g, %.6g]', v(1), v(2));
    end
end

% =====================================================================
function value = getfield_default(s, fieldName, defaultValue)

    if isstruct(s) && isfield(s, fieldName) && ~isempty(s.(fieldName))
        value = s.(fieldName);
    else
        value = defaultValue;
    end
end

% =====================================================================
function v = normalize_row(v)

    v = reshape(v, 1, []);
    if numel(v) ~= 3 || any(~isfinite(v))
        v = [NaN NaN NaN];
        return;
    end

    nv = norm(v);
    if nv < eps
        v = [NaN NaN NaN];
    else
        v = v ./ nv;
    end
end

% =====================================================================
function x = clamp_scalar(x, lo, hi)

    x = max(lo, min(hi, x));
end

% =====================================================================
function x = wrap_to_0_2pi(x)

    x = mod(x, 2*pi);
end

% =====================================================================
function y = cot_safe(x, epsSing)

    sx = sin(x);
    if abs(sx) < epsSing
        sx = sign(sx + eps) * epsSing;
    end
    y = cos(x) ./ sx;
end

% =====================================================================
function d = safe_den(d, epsSing)

    if abs(d) < epsSing
        d = sign(d + eps) * epsSing;
    end
end

% =====================================================================
function r = finite_range(v)

    v = v(:);
    v = v(isfinite(v));

    if isempty(v)
        r = [NaN NaN];
    else
        r = [min(v), max(v)];
    end
end