function [coord, facet, info] = stl_to_pofacets_model(stl_file, mat_file, varargin)
%STL_TO_POFACETS_MODEL Convert STL geometry to PoFacets model variables.
%
% This is a GUI-free version of the STL import logic originally embedded in
% utilities.m / ImportSTL_Callback of PoFacets.
%
% Usage:
%   stl_to_pofacets_model('input/case.stl', 'input/case_pofacets.mat');
%
% Optional name-value pairs:
%   'Scale'       : coordinate scale factor applied after import. Default = 1
%   'MergeTol'    : tolerance for merging vertices. Default = 0
%                   0 means exact duplicate merging like unique(A,'rows').
%                   Example: 1e-9 or 1e-6.
%   'FlipNormals' : true/false. If true, face node order is reversed.
%                   Default = false
%   'Verbose'     : true/false. Default = true
%
% Output variables saved to mat_file:
%   coord, facet, scale, symplanes, comments, matrl
%
% PoFacets facet format:
%   facet(:,1:3) = triangle vertex indices
%   facet(:,4)   = illumination flag, default 1
%   facet(:,5)   = surface resistivity Rs, default 0

    p = inputParser;
    addRequired(p, 'stl_file', @ischar);
    addOptional(p, 'mat_file', '', @ischar);
    addParameter(p, 'Scale', 1, @(x) isnumeric(x) && isscalar(x));
    addParameter(p, 'MergeTol', 0, @(x) isnumeric(x) && isscalar(x) && x >= 0);
    addParameter(p, 'FlipNormals', false, @(x) islogical(x) || isnumeric(x));
    addParameter(p, 'Verbose', true, @(x) islogical(x) || isnumeric(x));
    parse(p, stl_file, mat_file, varargin{:});

    stl_file = char(p.Results.stl_file);
    mat_file = char(p.Results.mat_file);
    scale = p.Results.Scale;
    mergeTol = p.Results.MergeTol;
    flipNormals = logical(p.Results.FlipNormals);
    verbose = logical(p.Results.Verbose);

    if ~exist(stl_file, 'file')
        error('STL file not found: %s', stl_file);
    end

    if isempty(mat_file)
        [stl_path, stl_name, ~] = fileparts(stl_file);
        mat_file = fullfile(stl_path, [stl_name '_pofacets.mat']);
    end

    if verbose
        fprintf('Importing STL: %s\n', stl_file);
    end

    % 1. Read STL.
    [V_raw, F_raw, modelname, readMode] = local_read_stl(stl_file);

    if isempty(V_raw) || isempty(F_raw)
        error('No valid triangle vertices were found in STL file: %s', stl_file);
    end

    % 2. Apply scale.
    V_raw = V_raw * scale;

    % 3. Merge duplicate vertices and rebuild face connectivity.
    if mergeTol > 0
        V_key = round(V_raw ./ mergeTol) .* mergeTol;
        [~, ia, ic] = unique(V_key, 'rows');
        coord = V_raw(ia, :);
    else
        [coord, ~, ic] = unique(V_raw, 'rows');
    end

    facet_nodes = reshape(ic(F_raw(:)), size(F_raw));

    % 4. Optional face orientation flip.
    if flipNormals
        facet_nodes = facet_nodes(:, [1 3 2]);
    end

    % 5. Build PoFacets facet array.
    ntria = size(facet_nodes, 1);
    ilum = ones(ntria, 1);
    Rs = zeros(ntria, 1);
    facet = [facet_nodes, ilum, Rs];

    % 6. Default PoFacets metadata.
    symplanes = [0 0 0];

    comments = cell(ntria, 1);
    matrl = cell(ntria, 2);
    for i = 1:ntria
        comments{i,1} = 'Model Surface';
        matrl{i,1} = 'PEC';
        matrl{i,2} = [0 0 0 0 0];
    end

    % 7. Save.
    out_dir = fileparts(mat_file);
    if ~isempty(out_dir) && ~exist(out_dir, 'dir')
        mkdir(out_dir);
    end

    save(mat_file, 'coord', 'facet', 'scale', 'symplanes', 'comments', 'matrl');

    % 8. Info.
    info = struct();
    info.stl_file = stl_file;
    info.mat_file = mat_file;
    info.modelname = modelname;
    info.readMode = readMode;
    info.scale = scale;
    info.mergeTol = mergeTol;
    info.flipNormals = flipNormals;
    info.nvert_raw = size(V_raw, 1);
    info.ntria = ntria;
    info.nvert = size(coord, 1);

    if verbose
        fprintf('STL read mode : %s\n', readMode);
        fprintf('Model name    : %s\n', modelname);
        fprintf('Raw vertices  : %d\n', info.nvert_raw);
        fprintf('Unique verts  : %d\n', info.nvert);
        fprintf('Triangles     : %d\n', info.ntria);
        fprintf('Saved MAT     : %s\n', mat_file);
    end
end


function [V, F, modelname, readMode] = local_read_stl(stl_file)
% Try ASCII STL first. If it fails, try MATLAB stlread or binary STL reader.

    [V, F, modelname] = local_read_ascii_stl(stl_file);

    if ~isempty(V) && ~isempty(F)
        readMode = 'ASCII';
        return;
    end

    % Try MATLAB built-in stlread if available.
    if exist('stlread', 'file') == 2
        try
            TR = stlread(stl_file);

            if isa(TR, 'triangulation')
                V0 = TR.Points;
                F0 = TR.ConnectivityList;
            elseif isstruct(TR)
                if isfield(TR, 'Points') && isfield(TR, 'ConnectivityList')
                    V0 = TR.Points;
                    F0 = TR.ConnectivityList;
                elseif isfield(TR, 'vertices') && isfield(TR, 'faces')
                    V0 = TR.vertices;
                    F0 = TR.faces;
                else
                    error('Unsupported stlread output structure.');
                end
            else
                error('Unsupported stlread output type.');
            end

            V = V0;
            F = F0;
            [~, modelname, ~] = fileparts(stl_file);
            readMode = 'stlread';
            return;
        catch
            % Continue to binary reader.
        end
    end

    [V, F, modelname] = local_read_binary_stl(stl_file);
    readMode = 'Binary';
end


function [V, F, modelname] = local_read_ascii_stl(stl_file)
% ASCII STL parser following the PoFacets ImportSTL_Callback logic:
% find lines containing 'vertex', read three numbers, every three vertices
% make one triangle.

    V = [];
    F = [];
    modelname = '';

    fid = fopen(stl_file, 'r');
    if fid < 0
        error('Cannot open STL file: %s', stl_file);
    end

    firstline = fgetl(fid);
    if ischar(firstline)
        modelname = strtrim(firstline);
    else
        fclose(fid);
        return;
    end

    A = zeros(0, 3);
    Nv = zeros(0, 3);
    nv = 0;
    nod = 0;
    ntri = 1;

    while ~feof(fid)
        line = fgetl(fid);
        if ~ischar(line)
            continue;
        end

        if ~isempty(strfind(lower(line), 'vertex')) %#ok<STREMP>
            cleanLine = strrep(lower(line), 'vertex', ' ');
            B = sscanf(cleanLine, '%f');

            if numel(B) >= 3
                nv = nv + 1;
                nod = nod + 1;

                A(nv, :) = B(1:3).';
                Nv(ntri, nod) = nv;

                if nod == 3
                    nod = 0;
                    ntri = ntri + 1;
                end
            end
        end
    end

    fclose(fid);

    if nv < 3 || isempty(Nv)
        V = [];
        F = [];
        return;
    end

    % Remove incomplete triangle if present.
    if size(Nv, 2) < 3
        V = [];
        F = [];
        return;
    end

    completeRows = all(Nv > 0, 2);
    F = Nv(completeRows, :);
    V = A;
end


function [V, F, modelname] = local_read_binary_stl(stl_file)
% Minimal binary STL reader. It converts each triangle to three raw vertices.
% Duplicate vertices are merged later in the main function.

    V = [];
    F = [];
    [~, modelname, ~] = fileparts(stl_file);

    fid = fopen(stl_file, 'rb');
    if fid < 0
        error('Cannot open STL file: %s', stl_file);
    end

    header = fread(fid, 80, '*uint8'); %#ok<NASGU>
    ntri = fread(fid, 1, 'uint32');

    if isempty(ntri) || ntri <= 0
        fclose(fid);
        error('Invalid binary STL triangle count.');
    end

    V = zeros(double(ntri) * 3, 3);
    F = zeros(double(ntri), 3);

    for i = 1:double(ntri)
        fread(fid, 3, 'float32');  % normal vector, not used
        v1 = fread(fid, 3, 'float32').';
        v2 = fread(fid, 3, 'float32').';
        v3 = fread(fid, 3, 'float32').';
        fread(fid, 1, 'uint16');   % attribute byte count

        idx = 3 * (i - 1) + 1;
        V(idx, :)     = double(v1);
        V(idx + 1, :) = double(v2);
        V(idx + 2, :) = double(v3);
        F(i, :) = [idx, idx + 1, idx + 2];
    end

    fclose(fid);
end
