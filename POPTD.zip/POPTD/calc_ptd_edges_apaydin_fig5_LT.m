function [Eptd_t, Eptd_p, info] = calc_ptd_edges_apaydin_fig5_LT(edgeData, ptdCtx, cfg)
%CALC_PTD_EDGES_APAYDIN_FIG5_LT
% Apaydin rectangular-plate Fig. 5 validation-only PTD module.
%
% Purpose
%   Reproduce the leading/trailing-edge first-order PTD fringe contribution
%   for the PEC rectangular plate case used in Fig. 5 of
%   "Diffraction at a Rectangular Plate: First-Order PTD Approximation".
%
% Scope
%   - Monostatic backscatter only.
%   - E-polarization only.
%   - Plate on X-Z plane, y = 0.
%   - a = 2 lambda in z direction.
%   - b = 4 lambda in x direction.
%   - Only leading and trailing edges are represented.
%   - Side-edge contribution is intentionally not included.
%
% How it is used in the current POPTD code
%   CalcMono_PO_PTD_core computes PO first. This module returns Eptd_t,
%   which is then coherently added to the PO theta-polarized scattered field.
%
% Important
%   This is a paper-specific validation module, not a general arbitrary-edge
%   PTD solver for UAV geometries.

    %#ok<*INUSD>

    if nargin < 1
        edgeData = [];
    end
    if nargin < 2 || isempty(ptdCtx)
        ptdCtx = struct();
    end
    if nargin < 3 || isempty(cfg)
        cfg = struct();
    end

    Eptd_t = complex(0,0);
    Eptd_p = complex(0,0);

    info = struct();
    info.module = 'calc_ptd_edges_apaydin_fig5_LT';
    info.status = 'initialized';
    info.message = '';

    lambda = getfield_default_local(ptdCtx, 'wave', NaN);
    k      = getfield_default_local(ptdCtx, 'k', NaN);
    phiDeg = getfield_default_local(ptdCtx, 'phi_deg', NaN);
    thetaDeg = getfield_default_local(ptdCtx, 'theta_deg', NaN);

    if ~isfinite(lambda) || lambda <= 0
        info.status = 'invalid_lambda';
        info.message = 'Invalid wavelength in ptdCtx.wave.';
        return;
    end
    if ~isfinite(k) || k <= 0
        k = 2*pi/lambda;
    end
    if ~isfinite(phiDeg)
        info.status = 'invalid_phi';
        info.message = 'Invalid phi angle in ptdCtx.phi_deg.';
        return;
    end

    aOverLambda = getfield_default_local(cfg, 'apaydinAOverLambda', 2.0);
    bOverLambda = getfield_default_local(cfg, 'apaydinBOverLambda', 4.0);
    a = aOverLambda * lambda;
    b = bOverLambda * lambda;

    % Fig. 5 is the monostatic condition phi = phi0.
    phi0 = deg2rad(phiDeg);
    phi  = phi0;

    % PO reference field and leading/trailing-edge fringe reference field.
    [Ez_PO_ref, Ez_FR_ref] = apaydin_epol_lt_fields(phi, phi0, a, b, k);

    % Optional phase/scale alignment:
    % The PoFacets facetRCS field can have a different global phase/sign from
    % the analytical field expression. For coherent Total = PO + Fringe, align
    % the analytical fringe field to the computed PO field at the same angle.
    useAlign = logical(getfield_default_local(cfg, 'apaydinPhaseAlignToPO', true));
    alignScale = complex(1,0);

    if useAlign && isfield(ptdCtx, 'sumt_po') && isfinite(real(ptdCtx.sumt_po)) && isfinite(imag(ptdCtx.sumt_po))
        if abs(Ez_PO_ref) > 1e-14
            alignScale = ptdCtx.sumt_po ./ Ez_PO_ref;
        else
            % Near PO nulls the ratio is ill-conditioned. Use unit scale there.
            alignScale = complex(1,0);
        end
    end

    Eptd_t = alignScale .* Ez_FR_ref;
    Eptd_p = complex(0,0);

    info.status = 'ok';
    info.message = 'Apaydin Fig. 5 E-pol leading/trailing PTD fringe field returned.';
    info.theta_deg = thetaDeg;
    info.phi_deg = phiDeg;
    info.lambda = lambda;
    info.k = k;
    info.a = a;
    info.b = b;
    info.aOverLambda = aOverLambda;
    info.bOverLambda = bOverLambda;
    info.Ez_PO_ref = Ez_PO_ref;
    info.Ez_FR_ref = Ez_FR_ref;
    info.alignScale = alignScale;
    info.Eptd_t = Eptd_t;
    info.Eptd_p = Eptd_p;

    if logical(getfield_default_local(cfg, 'ptdDebug', false))
        fprintf('--- Apaydin Fig.5 LT PTD module ---\n');
        fprintf('theta, phi        : %.6g, %.6g deg\n', thetaDeg, phiDeg);
        fprintf('a/lambda, b/lambda: %.6g, %.6g\n', aOverLambda, bOverLambda);
        fprintf('|Ez_PO_ref|       : %.6g\n', abs(Ez_PO_ref));
        fprintf('|Ez_FR_ref|       : %.6g\n', abs(Ez_FR_ref));
        fprintf('|alignScale|      : %.6g\n', abs(alignScale));
        fprintf('|Eptd_t|          : %.6g\n', abs(Eptd_t));
        fprintf('------------------------------------\n');
    end
end

% -------------------------------------------------------------------------
function [Ez_PO, Ez_FR] = apaydin_epol_lt_fields(phi, phi0, a, b, k)
    den = cos(phi) + cos(phi0);
    if abs(den) < 1e-12
        sterm = 0.5*k*b;
    else
        sterm = sin(0.5*k*b*den) ./ den;
    end

    % E-pol PO field for leading/trailing validation case.
    Ez_PO = 1i * a/pi .* sin(phi0) .* sterm;

    psi = 0.5*k*b*(cos(phi) + cos(phi0));

    phi_t  = pi - phi;
    phi0_t = pi - phi0;

    F_le = Fmod_E(phi,   phi0,   b, k);
    F_tr = Fmod_E(phi_t, phi0_t, b, k);

    Ez_FR = -a/pi .* (F_le .* exp( 1i*psi) + F_tr .* exp(-1i*psi));
end

% -------------------------------------------------------------------------
function F = Fmod_E(phi, phi0, l, k)
    F = B3(phi, phi0, l, k) .* sin(phi0) + B2(phi, l, k) .* sin(phi0/2);
end

% -------------------------------------------------------------------------
function val = B2(phi, l, k)
    oneMinusCos = 1 - cos(phi);
    if abs(oneMinusCos) < 1e-14
        oneMinusCos = 1e-14;
    end

    X = sqrt(k*l.*oneMinusCos);
    val = exp(-1i*pi/4)./sqrt(pi) .* sqrt(2./oneMinusCos) .* fresnel_exp_i_t2_0_to_x(X);
end

% -------------------------------------------------------------------------
function val = B3(phi, phi0, l, k)
    Phi = -cos(phi) - cos(phi0);
    if abs(Phi) < 1e-9
        epsAng = 1e-7;
        val = 0.5*(B3_direct(phi + epsAng, phi0, l, k) + ...
                   B3_direct(phi - epsAng, phi0, l, k));
    else
        val = B3_direct(phi, phi0, l, k);
    end
end

% -------------------------------------------------------------------------
function val = B3_direct(phi, phi0, l, k)
    Phi = -cos(phi) - cos(phi0);
    Xinf0 = sqrt(2*k*l).*cos(phi0/2);
    Iinf = fresnel_exp_i_t2_x_to_inf(Xinf0);

    val = ( exp(1i*k*l.*Phi).*exp(-1i*pi/4)./sqrt(pi).*Iinf ...
            - 0.5 + B2(phi, l, k).*cos(phi0/2) ) ./ Phi;
end

% -------------------------------------------------------------------------
function I = fresnel_exp_i_t2_0_to_x(x)
    % Computes integral_0^x exp(i t^2) dt
    % Numerical version used to avoid complex-erf compatibility issues.

    x = full(real(x));
    I = complex(zeros(size(x)));

    for ii = 1:numel(x)
        X = x(ii);

        if ~isfinite(X)
            I(ii) = complex(NaN, NaN);
            continue;
        end

        if abs(X) < 1e-12
            I(ii) = complex(0, 0);
            continue;
        end

        sgn = sign(X);
        Xabs = abs(X);

        Ival = integral( ...
            @(t) exp(1i*t.^2), ...
            0, Xabs, ...
            'ArrayValued', true, ...
            'RelTol', 1e-8, ...
            'AbsTol', 1e-10);

        I(ii) = sgn * Ival;
    end
end

function I = fresnel_exp_i_t2_x_to_inf(x)
    % Computes integral_x^inf exp(i t^2) dt
    % integral_0^inf exp(i t^2) dt = sqrt(pi)/2 * exp(i*pi/4)

    I0inf = 0.5 * sqrt(pi) * exp(1i*pi/4);
    I = I0inf - fresnel_exp_i_t2_0_to_x(x);
end

% -------------------------------------------------------------------------
function v = getfield_default_local(s, f, d)
    if isstruct(s) && isfield(s, f) && ~isempty(s.(f))
        v = s.(f);
    else
        v = d;
    end
end
