function edgeData = build_edge_data(coord, facet, edgeAdj, varargin)
%BUILD_EDGE_DATA Build PTD-ready edge geometry and sharp-edge candidates.
%
% Project : POPTD RCS module development
% Purpose : PTD edgeData generation step 2
%
% Usage:
%   edgeData = build_edge_data(coord, facet, edgeAdj);
%   edgeData = build_edge_data(coord, facet, edgeAdj, ...
%       'SharpAngleThresholdDeg', 30, ...
%       'MinEdgeLength', 1e-9, ...
%       'Verbose', true);
%
% Inputs:
%   coord   : [nVert x 3] vertex coordinates
%   facet   : PoFacets facet array. facet(:,1:3) are triangle indices.
%   edgeAdj : output structure from build_edge_adjacency.m
%
% Name-value options:
%   'SharpAngleThresholdDeg' : threshold for sharp-edge candidate selection.
%                              Default = 30 deg.
%   'MinEdgeLength'          : edges shorter than this are excluded from PTD use.
%                              Default = 1e-9.
%   'IncludeBoundaryEdges'   : true/false. Default = false.
%   'IncludeNonManifoldEdges': true/false. Default = false.
%   'Verbose'                : true/false. Default = true.
%
% Output structure:
%   edgeData.edges              : [nEdges x 2] unique edge vertex indices
%   edgeData.p1, p2             : [nEdges x 3] edge endpoint coordinates
%   edgeData.center             : [nEdges x 3] edge center coordinates
%   edgeData.length             : [nEdges x 1] edge length
%   edgeData.tangent            : [nEdges x 3] unit tangent vector
%   edgeData.adjacentFacets     : {nEdges x 1} adjacent facet list
%   edgeData.edgeFacetCount     : [nEdges x 1] number of adjacent facets
%   edgeData.normal1, normal2   : adjacent facet normals for manifold edges
%   edgeData.normalAngle_deg    : angle between adjacent facet normals
%   edgeData.wedgeInterior_deg  : preliminary interior wedge angle estimate
%   edgeData.wedgeExterior_deg  : preliminary exterior wedge angle estimate
%   edgeData.isSharp            : automatic sharp-edge candidate flag
%   edgeData.usePTD             : edge flag to be used by the PTD solver
%   edgeData.selectedEdgeIdx    : indices where usePTD = true
%
% Notes:
%   This function does not implement PTD equations. It only prepares edge
%   geometry and automatic sharp-edge candidates. The wedge angle stored here
%   is a preliminary estimate from adjacent facet normals. More detailed PTD
%   implementation may later replace this with an oriented wedge definition.

    % ---------------------------------------------------------------
    % 0. Options
    % ---------------------------------------------------------------
    opt = struct();
    opt.SharpAngleThresholdDeg = 30;
    opt.MinEdgeLength = 1e-9;
    opt.IncludeBoundaryEdges = false;
    opt.IncludeNonManifoldEdges = false;
    opt.Verbose = true;

    if mod(numel(varargin), 2) ~= 0
        error('build_edge_data:InputError', ...
              'Name-value options must be given in pairs.');
    end

    for k = 1:2:numel(varargin)
        name = varargin{k};
        value = varargin{k+1};
        if ~ischar(name) && ~isstring(name)
            error('build_edge_data:InputError', ...
                  'Option name must be a string.');
        end
        name = char(name);
        if ~isfield(opt, name)
            error('build_edge_data:InputError', ...
                  'Unknown option: %s', name);
        end
        opt.(name) = value;
    end

    % ---------------------------------------------------------------
    % 1. Validate inputs
    % ---------------------------------------------------------------
    if nargin < 3
        error('build_edge_data:InputError', ...
              'coord, facet, and edgeAdj are required.');
    end

    if isempty(coord) || size(coord, 2) ~= 3
        error('build_edge_data:InputError', ...
              'coord must be an [nVert x 3] array.');
    end

    if isempty(facet) || size(facet, 2) < 3
        error('build_edge_data:InputError', ...
              'facet must contain at least three columns.');
    end

    requiredFields = {'edges','adjacentFacets','edgeFacetCount','nEdges'};
    for i = 1:numel(requiredFields)
        if ~isfield(edgeAdj, requiredFields{i})
            error('build_edge_data:InputError', ...
                  'edgeAdj.%s field is missing.', requiredFields{i});
        end
    end

    F = round(facet(:, 1:3));
    V = coord;

    nVert = size(V, 1);
    nFacets = size(F, 1);
    nEdges = edgeAdj.nEdges;

    if any(F(:) < 1) || any(F(:) > nVert)
        error('build_edge_data:InputError', ...
              'facet contains vertex indices outside coord range.');
    end

    % ---------------------------------------------------------------
    % 2. Compute facet normals and areas
    % ---------------------------------------------------------------
    pA = V(F(:,1), :);
    pB = V(F(:,2), :);
    pC = V(F(:,3), :);

    crossVec = cross(pB - pA, pC - pA, 2);
    crossNorm = sqrt(sum(crossVec.^2, 2));
    facetArea = 0.5 * crossNorm;

    facetNormal = zeros(nFacets, 3);
    validFacet = crossNorm > eps;
    facetNormal(validFacet, :) = crossVec(validFacet, :) ./ crossNorm(validFacet);

    degenerateFacetIdx = find(~validFacet | ~isfinite(facetArea));

    % ---------------------------------------------------------------
    % 3. Compute edge geometry
    % ---------------------------------------------------------------
    edges = edgeAdj.edges;

    if any(edges(:) < 1) || any(edges(:) > nVert)
        error('build_edge_data:InputError', ...
              'edgeAdj.edges contains vertex indices outside coord range.');
    end

    p1 = V(edges(:,1), :);
    p2 = V(edges(:,2), :);
    edgeVec = p2 - p1;
    edgeLength = sqrt(sum(edgeVec.^2, 2));

    tangent = zeros(nEdges, 3);
    validEdgeLength = edgeLength > 0 & isfinite(edgeLength);
    tangent(validEdgeLength, :) = edgeVec(validEdgeLength, :) ./ edgeLength(validEdgeLength);

    center = 0.5 * (p1 + p2);

    % ---------------------------------------------------------------
    % 4. Adjacent-facet normal data and normal angle
    % ---------------------------------------------------------------
    edgeFacetCount = edgeAdj.edgeFacetCount(:);

    isBoundary = edgeFacetCount == 1;
    isManifold = edgeFacetCount == 2;
    isNonManifold = edgeFacetCount > 2;

    normal1 = nan(nEdges, 3);
    normal2 = nan(nEdges, 3);
    adjacentFacet1 = nan(nEdges, 1);
    adjacentFacet2 = nan(nEdges, 1);
    normalAngle_deg = nan(nEdges, 1);
    wedgeInterior_deg = nan(nEdges, 1);
    wedgeExterior_deg = nan(nEdges, 1);

    for e = 1:nEdges
        adj = edgeAdj.adjacentFacets{e};
        if isempty(adj)
            continue;
        end

        adjacentFacet1(e) = adj(1);
        normal1(e, :) = facetNormal(adj(1), :);

        if numel(adj) >= 2
            adjacentFacet2(e) = adj(2);
            normal2(e, :) = facetNormal(adj(2), :);

            n1 = normal1(e, :);
            n2 = normal2(e, :);

            if all(isfinite(n1)) && all(isfinite(n2)) && norm(n1) > 0 && norm(n2) > 0
                dotNN = dot(n1, n2);
                dotNN = max(-1, min(1, dotNN));
                normalAngle_deg(e) = acosd(dotNN);

                % Preliminary wedge estimates.
                % For a flat surface: normalAngle=0 -> interior wedge=180 deg.
                % For a convex 90-deg corner: normalAngle=90 -> interior wedge=90 deg.
                wedgeInterior_deg(e) = 180 - normalAngle_deg(e);
                wedgeExterior_deg(e) = 360 - wedgeInterior_deg(e);
            end
        end
    end

    % ---------------------------------------------------------------
    % 5. Automatic sharp-edge candidate selection
    % ---------------------------------------------------------------
    isLongEnough = edgeLength >= opt.MinEdgeLength;
    hasValidNormals = isfinite(normalAngle_deg);

    isSharp = false(nEdges, 1);
    isSharp(isManifold & isLongEnough & hasValidNormals & ...
            normalAngle_deg >= opt.SharpAngleThresholdDeg) = true;

    if opt.IncludeBoundaryEdges
        isSharp(isBoundary & isLongEnough) = true;
    end

    if opt.IncludeNonManifoldEdges
        isSharp(isNonManifold & isLongEnough) = true;
    end

    usePTD = isSharp;
    selectedEdgeIdx = find(usePTD);

    % ---------------------------------------------------------------
    % 6. Pack output
    % ---------------------------------------------------------------
    edgeData = struct();
    edgeData.edges = edges;
    edgeData.p1 = p1;
    edgeData.p2 = p2;
    edgeData.center = center;
    edgeData.length = edgeLength;
    edgeData.tangent = tangent;

    edgeData.adjacentFacets = edgeAdj.adjacentFacets;
    edgeData.edgeFacetCount = edgeFacetCount;
    edgeData.adjacentFacet1 = adjacentFacet1;
    edgeData.adjacentFacet2 = adjacentFacet2;

    edgeData.normal1 = normal1;
    edgeData.normal2 = normal2;
    edgeData.normalAngle_deg = normalAngle_deg;
    edgeData.dihedral_deg = normalAngle_deg;
    edgeData.wedgeInterior_deg = wedgeInterior_deg;
    edgeData.wedgeExterior_deg = wedgeExterior_deg;

    edgeData.isBoundary = isBoundary;
    edgeData.isManifold = isManifold;
    edgeData.isNonManifold = isNonManifold;
    edgeData.isSharp = isSharp;
    edgeData.usePTD = usePTD;
    edgeData.selectedEdgeIdx = selectedEdgeIdx;

    edgeData.facet = struct();
    edgeData.facet.normal = facetNormal;
    edgeData.facet.area = facetArea;
    edgeData.facet.degenerateFacetIdx = degenerateFacetIdx;

    edgeData.options = opt;
    edgeData.stats = struct();
    edgeData.stats.nVert = nVert;
    edgeData.stats.nFacets = nFacets;
    edgeData.stats.nEdges = nEdges;
    edgeData.stats.nBoundaryEdges = nnz(isBoundary);
    edgeData.stats.nManifoldEdges = nnz(isManifold);
    edgeData.stats.nNonManifoldEdges = nnz(isNonManifold);
    edgeData.stats.nDegenerateFacets = numel(degenerateFacetIdx);
    edgeData.stats.nZeroLengthEdges = nnz(~validEdgeLength);
    edgeData.stats.nSharpEdges = nnz(isSharp);
    edgeData.stats.nUsePTDEdges = nnz(usePTD);

    % ---------------------------------------------------------------
    % 7. Print summary
    % ---------------------------------------------------------------
    if opt.Verbose
        fprintf('--- build_edge_data summary ---\n');
        fprintf('Vertices              : %d\n', nVert);
        fprintf('Facets                : %d\n', nFacets);
        fprintf('Unique edges          : %d\n', nEdges);
        fprintf('Boundary edges        : %d\n', nnz(isBoundary));
        fprintf('Manifold edges        : %d\n', nnz(isManifold));
        fprintf('Non-manifold edges    : %d\n', nnz(isNonManifold));
        fprintf('Degenerate facets     : %d\n', numel(degenerateFacetIdx));
        fprintf('Zero-length edges     : %d\n', nnz(~validEdgeLength));
        fprintf('Sharp threshold       : %.6g deg\n', opt.SharpAngleThresholdDeg);
        fprintf('Sharp edge candidates : %d\n', nnz(isSharp));
        fprintf('usePTD edges          : %d\n', nnz(usePTD));
        fprintf('-------------------------------\n');
    end
end
