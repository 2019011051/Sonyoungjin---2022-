function hFig = plot_edge_candidates(coord, facet, edgeData, varargin)
%PLOT_EDGE_CANDIDATES Plot sharp/usePTD edge candidates on a 3D mesh.
%
% Project : POPTD RCS module development
% Purpose : Development/debug visualization for PTD edge candidate selection.
%
% Usage:
%   plot_edge_candidates(coord, facet, edgeData);
%   plot_edge_candidates(coord, facet, edgeData, 'Mode', 'usePTD');
%   plot_edge_candidates(coord, facet, edgeData, 'SaveFile', fullfile('output','edge_candidates.png'));
%
% Inputs:
%   coord    : [nVert x 3] vertex coordinates
%   facet    : PoFacets facet array. facet(:,1:3) are triangle indices.
%   edgeData : output from build_edge_data.m
%
% Name-value options:
%   'Mode'          : 'usePTD', 'isSharp', 'boundary', 'all'. Default = 'usePTD'
%   'ShowSurface'   : true/false. Default = true
%   'SurfaceAlpha'  : mesh surface transparency. Default = 0.12
%   'MaxEdges'      : maximum number of edge segments to plot. Default = Inf
%   'SelectBy'      : 'length' or 'index' when MaxEdges limits edges. Default = 'length'
%   'LineWidth'     : edge line width. Default = 1.5
%   'MarkerCenters' : true/false. Plot edge centers. Default = false
%   'Visible'       : 'on' or 'off'. Default = 'on'
%   'SaveFile'      : image file path. Default = ''
%   'View'          : 'iso', 'top', 'side', 'front'. Default = 'iso'
%   'AxisEqual'     : true/false. Default = true
%   'Verbose'       : true/false. Default = true
%
% Notes:
%   This is a development/debug function. It should not be called inside
%   PIAnO/RCE automated optimization loops unless Visible='off' and SaveFile
%   is intentionally specified.

    % ---------------------------------------------------------------
    % 0. Options
    % ---------------------------------------------------------------
    opt = struct();
    opt.Mode = 'usePTD';
    opt.ShowSurface = true;
    opt.SurfaceAlpha = 0.12;
    opt.MaxEdges = Inf;
    opt.SelectBy = 'length';
    opt.LineWidth = 1.5;
    opt.MarkerCenters = false;
    opt.Visible = 'on';
    opt.SaveFile = '';
    opt.View = 'iso';
    opt.AxisEqual = true;
    opt.Verbose = true;

    if mod(numel(varargin), 2) ~= 0
        error('plot_edge_candidates:InputError', ...
              'Name-value options must be given in pairs.');
    end

    for k = 1:2:numel(varargin)
        name = varargin{k};
        value = varargin{k+1};
        if ~ischar(name) && ~isstring(name)
            error('plot_edge_candidates:InputError', ...
                  'Option name must be a string.');
        end
        name = char(name);
        if ~isfield(opt, name)
            error('plot_edge_candidates:InputError', ...
                  'Unknown option: %s', name);
        end
        opt.(name) = value;
    end

    opt.Mode = char(opt.Mode);
    opt.SelectBy = char(opt.SelectBy);
    opt.Visible = char(opt.Visible);
    opt.View = char(opt.View);

    % ---------------------------------------------------------------
    % 1. Validate inputs
    % ---------------------------------------------------------------
    if nargin < 3
        error('plot_edge_candidates:InputError', ...
              'coord, facet, and edgeData are required.');
    end

    if isempty(coord) || size(coord, 2) ~= 3
        error('plot_edge_candidates:InputError', ...
              'coord must be an [nVert x 3] array.');
    end

    if isempty(facet) || size(facet, 2) < 3
        error('plot_edge_candidates:InputError', ...
              'facet must contain at least three columns.');
    end

    requiredFields = {'p1','p2','length'};
    for i = 1:numel(requiredFields)
        if ~isfield(edgeData, requiredFields{i})
            error('plot_edge_candidates:InputError', ...
                  'edgeData.%s field is missing.', requiredFields{i});
        end
    end

    F = round(facet(:, 1:3));
    V = coord;
    nEdges = size(edgeData.p1, 1);

    % ---------------------------------------------------------------
    % 2. Select edge indices
    % ---------------------------------------------------------------
    switch lower(opt.Mode)
        case 'useptd'
            if ~isfield(edgeData, 'usePTD')
                error('plot_edge_candidates:InputError', ...
                      'edgeData.usePTD field is missing.');
            end
            idx = find(edgeData.usePTD(:));
            modeLabel = 'usePTD edges';
        case 'issharp'
            if ~isfield(edgeData, 'isSharp')
                error('plot_edge_candidates:InputError', ...
                      'edgeData.isSharp field is missing.');
            end
            idx = find(edgeData.isSharp(:));
            modeLabel = 'sharp edge candidates';
        case 'boundary'
            if ~isfield(edgeData, 'isBoundary')
                error('plot_edge_candidates:InputError', ...
                      'edgeData.isBoundary field is missing.');
            end
            idx = find(edgeData.isBoundary(:));
            modeLabel = 'boundary edges';
        case 'all'
            idx = (1:nEdges).';
            modeLabel = 'all mesh edges';
        otherwise
            error('plot_edge_candidates:InputError', ...
                  'Unknown Mode: %s. Use usePTD, isSharp, boundary, or all.', opt.Mode);
    end

    nSelectedOriginal = numel(idx);

    if isempty(idx)
        warning('plot_edge_candidates:NoEdges', ...
                'No edges selected for Mode = %s.', opt.Mode);
    end

    % Limit plotted edges if requested.
    if isfinite(opt.MaxEdges) && numel(idx) > opt.MaxEdges
        switch lower(opt.SelectBy)
            case 'length'
                [~, order] = sort(edgeData.length(idx), 'descend');
                idx = idx(order(1:opt.MaxEdges));
            case 'index'
                idx = idx(1:opt.MaxEdges);
            otherwise
                error('plot_edge_candidates:InputError', ...
                      'Unknown SelectBy: %s. Use length or index.', opt.SelectBy);
        end
    end

    % ---------------------------------------------------------------
    % 3. Create figure
    % ---------------------------------------------------------------
    hFig = figure('Color', 'w', 'Visible', opt.Visible);
    hold on;

    if opt.ShowSurface
        patch('Faces', F, 'Vertices', V, ...
              'FaceColor', [0.75 0.75 0.75], ...
              'EdgeColor', 'none', ...
              'FaceAlpha', opt.SurfaceAlpha);
    end

    if ~isempty(idx)
        p1 = edgeData.p1(idx, :);
        p2 = edgeData.p2(idx, :);

        X = [p1(:,1) p2(:,1) nan(numel(idx),1)].';
        Y = [p1(:,2) p2(:,2) nan(numel(idx),1)].';
        Z = [p1(:,3) p2(:,3) nan(numel(idx),1)].';

        plot3(X(:), Y(:), Z(:), 'r-', 'LineWidth', opt.LineWidth);

        if opt.MarkerCenters
            centers = 0.5 * (p1 + p2);
            plot3(centers(:,1), centers(:,2), centers(:,3), 'k.', 'MarkerSize', 6);
        end
    end

    grid on;
    box on;
    xlabel('X');
    ylabel('Y');
    zlabel('Z');

    if opt.AxisEqual
        axis equal;
    end

    title(sprintf('PTD edge candidate visualization: %s (%d plotted / %d selected)', ...
          modeLabel, numel(idx), nSelectedOriginal), 'Interpreter', 'none');

    switch lower(opt.View)
        case 'iso'
            view(3);
        case 'top'
            view(0, 90);
        case 'side'
            view(90, 0);
        case 'front'
            view(0, 0);
        otherwise
            view(3);
    end

    camlight('headlight');
    lighting gouraud;

    % ---------------------------------------------------------------
    % 4. Save if requested
    % ---------------------------------------------------------------
    if ~isempty(opt.SaveFile)
        saveDir = fileparts(opt.SaveFile);
        if ~isempty(saveDir) && ~isfolder(saveDir)
            mkdir(saveDir);
        end
        try
            exportgraphics(hFig, opt.SaveFile, 'Resolution', 200);
        catch
            saveas(hFig, opt.SaveFile);
        end
    end

    % ---------------------------------------------------------------
    % 5. Print summary
    % ---------------------------------------------------------------
    if opt.Verbose
        fprintf('--- plot_edge_candidates summary ---\n');
        fprintf('Mode                  : %s\n', opt.Mode);
        fprintf('Selected edges         : %d\n', nSelectedOriginal);
        fprintf('Plotted edges          : %d\n', numel(idx));
        if ~isempty(idx)
            fprintf('Min plotted length     : %.12g\n', min(edgeData.length(idx)));
            fprintf('Max plotted length     : %.12g\n', max(edgeData.length(idx)));
            if isfield(edgeData, 'normalAngle_deg')
                ang = edgeData.normalAngle_deg(idx);
                ang = ang(isfinite(ang));
                if ~isempty(ang)
                    fprintf('Min plotted angle deg  : %.12g\n', min(ang));
                    fprintf('Max plotted angle deg  : %.12g\n', max(ang));
                end
            end
        end
        if ~isempty(opt.SaveFile)
            fprintf('Saved image            : %s\n', opt.SaveFile);
        end
        fprintf('------------------------------------\n');
    end
end
