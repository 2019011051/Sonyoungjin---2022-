function edgeAdj = build_edge_adjacency(facet, varargin)
%BUILD_EDGE_ADJACENCY Build unique mesh edges and adjacent facet lists.
%
% Project : POPTD RCS module development
% Purpose : PTD edgeData generation step 1
%
% Usage:
%   edgeAdj = build_edge_adjacency(facet);
%   edgeAdj = build_edge_adjacency(facet, 'Verbose', true);
%
% Input:
%   facet : PoFacets facet array.
%           facet(:,1:3) must contain triangle vertex indices.
%           Additional columns such as illumination flag and Rs are ignored.
%
% Name-value options:
%   'Verbose' : true/false, print edge statistics. Default = true.
%
% Output structure:
%   edgeAdj.edges             : [nEdges x 2] unique vertex index pairs [v1 v2]
%   edgeAdj.adjacentFacets    : {nEdges x 1} cell, adjacent facet indices for each edge
%   edgeAdj.edgeFacetCount    : [nEdges x 1] number of adjacent facets
%   edgeAdj.boundaryEdgeIdx   : edge indices with one adjacent facet
%   edgeAdj.manifoldEdgeIdx   : edge indices with two adjacent facets
%   edgeAdj.nonManifoldEdgeIdx: edge indices with three or more adjacent facets
%   edgeAdj.nEdges            : number of unique edges
%   edgeAdj.nFacets           : number of input triangular facets
%   edgeAdj.raw               : raw edge information for debugging
%
% Notes:
%   This function only builds mesh connectivity. It does not decide whether
%   an edge is a physical sharp edge. Sharp-edge classification is handled
%   later in build_edge_data.m using adjacent facet normals and dihedral angle.

    % ---------------------------------------------------------------
    % 0. Options
    % ---------------------------------------------------------------
    opt = struct();
    opt.Verbose = true;

    if mod(numel(varargin), 2) ~= 0
        error('build_edge_adjacency:InputError', ...
              'Name-value options must be given in pairs.');
    end

    for k = 1:2:numel(varargin)
        name = varargin{k};
        value = varargin{k+1};
        if ~ischar(name) && ~isstring(name)
            error('build_edge_adjacency:InputError', ...
                  'Option name must be a string.');
        end
        name = char(name);
        if ~isfield(opt, name)
            error('build_edge_adjacency:InputError', ...
                  'Unknown option: %s', name);
        end
        opt.(name) = value;
    end

    % ---------------------------------------------------------------
    % 1. Validate input facet array
    % ---------------------------------------------------------------
    if nargin < 1 || isempty(facet)
        error('build_edge_adjacency:InputError', 'facet input is empty.');
    end

    if size(facet, 2) < 3
        error('build_edge_adjacency:InputError', ...
              'facet must have at least three columns containing triangle vertex indices.');
    end

    F = facet(:, 1:3);
    if ~isnumeric(F)
        error('build_edge_adjacency:InputError', ...
              'facet(:,1:3) must be numeric vertex indices.');
    end

    if any(~isfinite(F(:))) || any(F(:) <= 0)
        error('build_edge_adjacency:InputError', ...
              'facet(:,1:3) contains invalid vertex indices.');
    end

    % Make sure indices are integer-like.
    if any(abs(F(:) - round(F(:))) > 0)
        error('build_edge_adjacency:InputError', ...
              'facet(:,1:3) must contain integer vertex indices.');
    end
    F = round(F);

    nFacets = size(F, 1);

    % ---------------------------------------------------------------
    % 2. Generate three edges from each triangular facet
    % ---------------------------------------------------------------
    % Oriented raw edges are kept for debugging, but unique edge matching
    % uses sorted vertex pairs so that [v1 v2] and [v2 v1] are the same edge.
    e12 = F(:, [1 2]);
    e23 = F(:, [2 3]);
    e31 = F(:, [3 1]);

    rawEdges = [e12; e23; e31];
    rawFacetIds = [(1:nFacets)'; (1:nFacets)'; (1:nFacets)'];
    rawLocalEdgeIds = [ones(nFacets,1); 2*ones(nFacets,1); 3*ones(nFacets,1)];

    sortedRawEdges = sort(rawEdges, 2);

    % ---------------------------------------------------------------
    % 3. Sort edges and group identical vertex pairs
    % ---------------------------------------------------------------
    [sortedEdgesAll, order] = sortrows(sortedRawEdges, [1 2]);
    sortedRawEdgesOriented = rawEdges(order, :);
    sortedFacetIds = rawFacetIds(order);
    sortedLocalEdgeIds = rawLocalEdgeIds(order);

    isNewEdge = [true; any(diff(sortedEdgesAll, 1, 1) ~= 0, 2)];
    groupId = cumsum(isNewEdge);
    nEdges = groupId(end);

    uniqueEdges = sortedEdgesAll(isNewEdge, :);

    % ---------------------------------------------------------------
    % 4. Build adjacent facet list for each unique edge
    % ---------------------------------------------------------------
    adjacentFacets = accumarray(groupId, sortedFacetIds, [nEdges 1], @(x){x(:).'});
    adjacentLocalEdges = accumarray(groupId, sortedLocalEdgeIds, [nEdges 1], @(x){x(:).'});
    adjacentOrientedEdges = accumarray(groupId, (1:numel(groupId))', [nEdges 1], ...
        @(idx){sortedRawEdgesOriented(idx, :)});

    edgeFacetCount = cellfun(@numel, adjacentFacets);

    boundaryEdgeIdx = find(edgeFacetCount == 1);
    manifoldEdgeIdx = find(edgeFacetCount == 2);
    nonManifoldEdgeIdx = find(edgeFacetCount > 2);

    % ---------------------------------------------------------------
    % 5. Pack output
    % ---------------------------------------------------------------
    edgeAdj = struct();
    edgeAdj.edges = uniqueEdges;
    edgeAdj.adjacentFacets = adjacentFacets;
    edgeAdj.adjacentLocalEdges = adjacentLocalEdges;
    edgeAdj.adjacentOrientedEdges = adjacentOrientedEdges;
    edgeAdj.edgeFacetCount = edgeFacetCount;

    edgeAdj.boundaryEdgeIdx = boundaryEdgeIdx;
    edgeAdj.manifoldEdgeIdx = manifoldEdgeIdx;
    edgeAdj.nonManifoldEdgeIdx = nonManifoldEdgeIdx;

    edgeAdj.nEdges = nEdges;
    edgeAdj.nFacets = nFacets;

    edgeAdj.raw = struct();
    edgeAdj.raw.edges = rawEdges;
    edgeAdj.raw.sortedEdges = sortedRawEdges;
    edgeAdj.raw.facetIds = rawFacetIds;
    edgeAdj.raw.localEdgeIds = rawLocalEdgeIds;

    % ---------------------------------------------------------------
    % 6. Print summary
    % ---------------------------------------------------------------
    if opt.Verbose
        fprintf('--- build_edge_adjacency summary ---\n');
        fprintf('Input facets          : %d\n', nFacets);
        fprintf('Raw mesh edges        : %d\n', size(rawEdges, 1));
        fprintf('Unique mesh edges     : %d\n', nEdges);
        fprintf('Boundary edges        : %d\n', numel(boundaryEdgeIdx));
        fprintf('Manifold edges        : %d\n', numel(manifoldEdgeIdx));
        fprintf('Non-manifold edges    : %d\n', numel(nonManifoldEdgeIdx));
        fprintf('------------------------------------\n');
    end
end
