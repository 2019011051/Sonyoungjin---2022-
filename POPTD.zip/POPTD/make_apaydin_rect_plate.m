clear; clc; close all;

% ==========================================================
% Apaydin et al. rectangular PEC plate
% a = 2 lambda, b = 4 lambda
% Plate region:
%   -b/2 <= x <= b/2
%   -a/2 <= z <= a/2
%   y = 0 plane, implemented as a very thin solid plate
% ==========================================================

c0 = 299792458;

lambda = 0.0325;          % [m], 3.25 cm
freq = c0 / lambda;       % [Hz]

a = 2 * lambda;           % z-direction length
b = 4 * lambda;           % x-direction length
t = lambda / 200;         % thin plate thickness in y-direction

Nx = 80;                  % x divisions
Nz = 40;                  % z divisions

fprintf('lambda = %.6f m\n', lambda);
fprintf('freq   = %.6f GHz\n', freq/1e9);
fprintf('a      = %.6f m\n', a);
fprintf('b      = %.6f m\n', b);
fprintf('t      = %.6f m\n', t);

% Coordinates
x = linspace(-b/2, b/2, Nx+1);
z = linspace(-a/2, a/2, Nz+1);

coord = [];
facet = [];

% Helper for adding vertices
addVertex = @(P) size(P,1) + 1;

% ==========================================================
% 1. Top surface y = +t/2
% ==========================================================
topID = zeros(Nz+1, Nx+1);

for iz = 1:Nz+1
    for ix = 1:Nx+1
        coord(end+1,:) = [x(ix), +t/2, z(iz)];
        topID(iz,ix) = size(coord,1);
    end
end

for iz = 1:Nz
    for ix = 1:Nx
        v1 = topID(iz,ix);
        v2 = topID(iz,ix+1);
        v3 = topID(iz+1,ix+1);
        v4 = topID(iz+1,ix);

        % top normal should be +y
        facet(end+1,:) = [v1 v3 v2 0];
        facet(end+1,:) = [v1 v4 v3 0];
    end
end

% ==========================================================
% 2. Bottom surface y = -t/2
% ==========================================================
botID = zeros(Nz+1, Nx+1);

for iz = 1:Nz+1
    for ix = 1:Nx+1
        coord(end+1,:) = [x(ix), -t/2, z(iz)];
        botID(iz,ix) = size(coord,1);
    end
end

for iz = 1:Nz
    for ix = 1:Nx
        v1 = botID(iz,ix);
        v2 = botID(iz,ix+1);
        v3 = botID(iz+1,ix+1);
        v4 = botID(iz+1,ix);

        % bottom normal should be -y
        facet(end+1,:) = [v1 v2 v3 0];
        facet(end+1,:) = [v1 v3 v4 0];
    end
end

% ==========================================================
% 3. Side surfaces
% ==========================================================

% x = -b/2 side
for iz = 1:Nz
    vt1 = topID(iz,1);
    vt2 = topID(iz+1,1);
    vb1 = botID(iz,1);
    vb2 = botID(iz+1,1);

    facet(end+1,:) = [vb1 vt2 vt1 0];
    facet(end+1,:) = [vb1 vb2 vt2 0];
end

% x = +b/2 side
for iz = 1:Nz
    vt1 = topID(iz,end);
    vt2 = topID(iz+1,end);
    vb1 = botID(iz,end);
    vb2 = botID(iz+1,end);

    facet(end+1,:) = [vb1 vt1 vt2 0];
    facet(end+1,:) = [vb1 vt2 vb2 0];
end

% z = -a/2 side
for ix = 1:Nx
    vt1 = topID(1,ix);
    vt2 = topID(1,ix+1);
    vb1 = botID(1,ix);
    vb2 = botID(1,ix+1);

    facet(end+1,:) = [vb1 vt1 vt2 0];
    facet(end+1,:) = [vb1 vt2 vb2 0];
end

% z = +a/2 side
for ix = 1:Nx
    vt1 = topID(end,ix);
    vt2 = topID(end,ix+1);
    vb1 = botID(end,ix);
    vb2 = botID(end,ix+1);

    facet(end+1,:) = [vb1 vt2 vt1 0];
    facet(end+1,:) = [vb1 vb2 vt2 0];
end

% ==========================================================
% Save PoFacets-style MAT
% ==========================================================
outMat = 'apaydin_rect_plate_pofacets.mat';
save(outMat, 'coord', 'facet', 'lambda', 'freq', 'a', 'b', 't', 'Nx', 'Nz');

fprintf('Saved MAT: %s\n', outMat);
fprintf('coord size: %d x %d\n', size(coord,1), size(coord,2));
fprintf('facet size: %d x %d\n', size(facet,1), size(facet,2));

% ==========================================================
% Save ASCII STL
% ==========================================================
outStl = 'apaydin_rect_plate.stl';
write_ascii_stl(outStl, coord, facet(:,1:3));

fprintf('Saved STL: %s\n', outStl);

% ==========================================================
% Plot check
% ==========================================================
figure;
trisurf(facet(:,1:3), coord(:,1), coord(:,2), coord(:,3), ...
    'FaceColor', [0.8 0.8 0.8], ...
    'EdgeColor', 'k', ...
    'FaceAlpha', 0.7);

axis equal;
grid on;
xlabel('X [m]');
ylabel('Y [m]');
zlabel('Z [m]');
title('Apaydin Rectangular PEC Plate: a = 2\lambda, b = 4\lambda');
view(3);

% ==========================================================
% Local function: ASCII STL writer
% ==========================================================
function write_ascii_stl(filename, V, F)

    fid = fopen(filename, 'w');
    if fid < 0
        error('Cannot open STL file for writing: %s', filename);
    end

    fprintf(fid, 'solid apaydin_rect_plate\n');

    for i = 1:size(F,1)
        p1 = V(F(i,1),:);
        p2 = V(F(i,2),:);
        p3 = V(F(i,3),:);

        n = cross(p2-p1, p3-p1);
        nn = norm(n);
        if nn > 0
            n = n / nn;
        else
            n = [0 0 0];
        end

        fprintf(fid, '  facet normal %.9e %.9e %.9e\n', n(1), n(2), n(3));
        fprintf(fid, '    outer loop\n');
        fprintf(fid, '      vertex %.9e %.9e %.9e\n', p1(1), p1(2), p1(3));
        fprintf(fid, '      vertex %.9e %.9e %.9e\n', p2(1), p2(2), p2(3));
        fprintf(fid, '      vertex %.9e %.9e %.9e\n', p3(1), p3(2), p3(3));
        fprintf(fid, '    endloop\n');
        fprintf(fid, '  endfacet\n');
    end

    fprintf(fid, 'endsolid apaydin_rect_plate\n');
    fclose(fid);
end