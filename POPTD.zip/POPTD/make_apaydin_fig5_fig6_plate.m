function make_apaydin_fig5_fig6_plate()
% ============================================================
% Apaydin Fig. 5 / Fig. 6 rectangular PEC plate generator
%
% Geometry:
%   zero-thickness rectangular plate on x-z plane
%   y = 0
%   x length = b = 4 lambda
%   z length = a = 2 lambda
%
% Output:
%   input/apaydin_fig5_fig6_plate_pofacets.mat
% ============================================================

clear; clc; close all;

%% 1. Basic condition
c0 = 299792458;      % speed of light [m/s]
lambda = 1.0;        % wavelength [m]
freq = c0 / lambda;  % frequency [Hz]
k = 2*pi/lambda;

a = 2*lambda;        % z-direction length [m]
b = 4*lambda;        % x-direction length [m]

%% 2. Mesh resolution
% 10 x 10 rectangular cells -> 200 triangular facets
nx = 80;
nz = 40;

xv = linspace(-b/2, b/2, nx+1);
zv = linspace(-a/2, a/2, nz+1);

[X, Z] = meshgrid(xv, zv);
Y = zeros(size(X));

coord = [X(:), Y(:), Z(:)];

%% 3. Facet generation
% Vertex ordering is chosen so that facet normal points to +y.
tri = [];

node_id = @(iz, ix) (iz-1)*(nx+1) + ix;

for iz = 1:nz
    for ix = 1:nx
        p00 = node_id(iz,   ix);
        p10 = node_id(iz,   ix+1);
        p01 = node_id(iz+1, ix);
        p11 = node_id(iz+1, ix+1);

        % normal +y
        tri = [tri;
               p00, p01, p11;
               p00, p11, p10];
    end
end

% PoFacets-style facet format: [v1 v2 v3 0]
facet = [tri, zeros(size(tri,1),1)];

%% 4. Save
if ~exist('input','dir')
    mkdir('input');
end

outFile = fullfile('input','apaydin_fig5_fig6_plate_pofacets.mat');

save(outFile, ...
    'coord', 'facet', ...
    'lambda', 'freq', 'k', 'a', 'b', ...
    'nx', 'nz');

fprintf('Saved: %s\n', outFile);
fprintf('lambda = %.6f m\n', lambda);
fprintf('freq   = %.6f MHz\n', freq/1e6);
fprintf('a      = %.6f m\n', a);
fprintf('b      = %.6f m\n', b);
fprintf('coord  = %d nodes\n', size(coord,1));
fprintf('facet  = %d triangles\n', size(facet,1));

%% 5. Plot check
figure;
trisurf(facet(:,1:3), coord(:,1), coord(:,2), coord(:,3), ...
    'FaceColor', [0.8 0.8 0.8], ...
    'EdgeColor', 'k');
axis equal;
grid on;
xlabel('x [m]');
ylabel('y [m]');
zlabel('z [m]');
title('Apaydin Fig. 5/6 rectangular plate: a = 2\lambda, b = 4\lambda');
view(35,25);

end