function result = CalcMono_core(coord, facet, cfg)
% CalcMono_core.m
% GUI 제거 버전의 PoFacets monostatic PO RCS 계산 core 함수
%
% 목적:
%   기존 PoFacets의 CalcMono.m 계산부를 자동화/최적화 연동용으로 분리함.
%   GUI, waitbar, figure, questdlg, uiputfile 등을 사용하지 않음.
%
% 입력:
%   coord : [nvert x 3] vertex 좌표
%   facet : [ntria x 5] 또는 [ntria x 3]
%           facet(:,1:3) = vertex index
%           facet(:,4)   = illumination flag, 없으면 1로 설정
%           facet(:,5)   = surface resistivity Rs, 없으면 0으로 설정
%   cfg   : 해석 조건 구조체
%
% 주요 cfg 필드:
%   cfg.C         = 광속 [m/s], 기본값 299792458
%   cfg.freqGHz   = 주파수 [GHz], 기본값 10
%   cfg.tstart    = theta 시작각 [deg], 기본값 90
%   cfg.tstop     = theta 종료각 [deg], 기본값 90
%   cfg.delt      = theta 간격 [deg], 기본값 1
%   cfg.pstart    = phi 시작각 [deg], 기본값 0
%   cfg.pstop     = phi 종료각 [deg], 기본값 360
%   cfg.delp      = phi 간격 [deg], 기본값 5
%   cfg.i_pol     = 입사 편파, 1 theta-pol, 2 phi-pol, 기본값 1
%   cfg.RsDefault = facet(:,5)가 없을 때 Rs 기본값, 기본값 0
%   cfg.Nt        = Taylor series terms, 기본값 10
%   cfg.Lt        = Taylor region threshold, 기본값 0.01
%   cfg.corr      = surface correlation length [m], 기본값 0
%   cfg.std       = surface rms roughness [m], 기본값 0
%   cfg.rsmethod  = 1만 지원함. 1 = Rs 사용
%   cfg.iflag     = illumination test off flag, 기본값 0
%   cfg.clipFloor = 결과 표시용 dynamic floor 사용 여부, 기본값 false
%
% 출력:
%   result 구조체
%     result.theta, result.phi       : angle grid [deg]
%     result.Sth_raw, result.Sph_raw : clipping 전 RCS [dBsm]
%     result.Sth, result.Sph         : clipping 적용 또는 raw RCS [dBsm]
%     result.Ethscat, result.Ephscat : 복소 산란장 합
%     result.RCSth_linear, result.RCSph_linear : 선형 RCS
%     result.metrics                 : avg/max 등 요약값
%     result.mesh                    : normal, area 등 전처리 값
%
% 주의:
%   본 함수는 초기 자동화용 PO-only core임.
%   ground plane, symmetry, material-layer RC 계산은 의도적으로 제외함.
%   PTD는 다음 단계에서 CalcMono_PO_PTD_core.m에 추가하는 것을 권장함.

    if nargin < 3
        cfg = struct();
    end

    % -----------------------------
    % 1. 기본 설정값
    % -----------------------------
    cfg.C         = getcfg(cfg, 'C', 299792458);
    cfg.freqGHz   = getcfg(cfg, 'freqGHz', 10);
    cfg.tstart    = getcfg(cfg, 'tstart', 90);
    cfg.tstop     = getcfg(cfg, 'tstop', 90);
    cfg.delt      = getcfg(cfg, 'delt', 1);
    cfg.pstart    = getcfg(cfg, 'pstart', 0);
    cfg.pstop     = getcfg(cfg, 'pstop', 360);
    cfg.delp      = getcfg(cfg, 'delp', 5);
    cfg.i_pol     = getcfg(cfg, 'i_pol', 1);
    cfg.RsDefault = getcfg(cfg, 'RsDefault', 0);
    cfg.Nt        = getcfg(cfg, 'Nt', 10);
    cfg.Lt        = getcfg(cfg, 'Lt', 0.01);
    cfg.corr      = getcfg(cfg, 'corr', 0);
    cfg.std       = getcfg(cfg, 'std', 0);
    cfg.rsmethod  = getcfg(cfg, 'rsmethod', 1);
    cfg.iflag     = getcfg(cfg, 'iflag', 0);
    cfg.clipFloor = getcfg(cfg, 'clipFloor', false);

    if cfg.rsmethod ~= 1
        error('CalcMono_core:rsmethod', ...
              '현재 CalcMono_core.m 초기 버전은 rsmethod=1, 즉 Rs 방식만 지원함.');
    end

    if cfg.i_pol ~= 1 && cfg.i_pol ~= 2
        error('CalcMono_core:polarization', ...
              'cfg.i_pol은 1(theta-pol) 또는 2(phi-pol)이어야 함.');
    end

    % -----------------------------
    % 2. 입력 형상 정리
    % -----------------------------
    if size(coord,2) ~= 3
        error('CalcMono_core:coord', 'coord는 [nvert x 3] 형식이어야 함.');
    end

    if size(facet,2) < 3
        error('CalcMono_core:facet', 'facet은 최소 [ntria x 3] 형식이어야 함.');
    end

    nvert = size(coord,1);
    ntria = size(facet,1);

    if size(facet,2) == 3
        facet(:,4) = 1;
        facet(:,5) = cfg.RsDefault;
    elseif size(facet,2) == 4
        facet(:,5) = cfg.RsDefault;
    end

    node1 = facet(:,1);
    node2 = facet(:,2);
    node3 = facet(:,3);
    ilum  = facet(:,4);
    Rs    = facet(:,5);

    if any(node1 < 1 | node1 > nvert | node2 < 1 | node2 > nvert | node3 < 1 | node3 > nvert)
        error('CalcMono_core:facetIndex', 'facet의 vertex index가 coord 범위를 벗어남.');
    end

    x = coord(:,1);
    y = coord(:,2);
    z = coord(:,3);

    vind = zeros(ntria,3);
    r    = zeros(nvert,3);

    for i = 1:ntria
        vind(i,:) = [node1(i), node2(i), node3(i)];
    end

    for i = 1:nvert
        r(i,:) = [x(i), y(i), z(i)];
    end

    % -----------------------------
    % 3. facet geometry 계산
    % -----------------------------
    N     = zeros(ntria,3);
    Area  = zeros(ntria,1);
    d     = zeros(ntria,3);
    alpha = zeros(ntria,1);
    beta  = zeros(ntria,1);

    for i = 1:ntria
        A = r(vind(i,2),:) - r(vind(i,1),:);
        B = r(vind(i,3),:) - r(vind(i,2),:);
        Cedge = r(vind(i,1),:) - r(vind(i,3),:);

        % 기존 CalcMono.m과 동일한 normal 정의
        Nraw = -cross(B,A);

        d(i,1) = norm(A);
        d(i,2) = norm(B);
        d(i,3) = norm(Cedge);

        ss = 0.5 * sum(d(i,:));
        areaVal = sqrt(max(ss*(ss-d(i,1))*(ss-d(i,2))*(ss-d(i,3)), 0));
        Area(i) = areaVal;

        Nn = norm(Nraw);
        if Nn < eps || areaVal < eps
            warning('CalcMono_core:degenerateFacet', ...
                    'Degenerate facet detected at index %d. Area or normal is nearly zero.', i);
            N(i,:) = [0 0 1];
        else
            N(i,:) = Nraw / Nn;
        end

        beta(i)  = acos(max(min(N(i,3),1),-1));
        alpha(i) = atan2(N(i,2),N(i,1));
    end

    % -----------------------------
    % 4. 전자파 파라미터
    % -----------------------------
    freqHz = cfg.freqGHz * 1e9;
    wave   = cfg.C / freqHz;
    bk     = 2*pi/wave;

    corel  = cfg.corr / wave;
    delstd = cfg.std;
    delsq  = delstd^2;

    cfac1  = exp(-4*bk^2*delsq);
    cfac2  = 4*pi*(bk*corel)^2*delsq;
    rad    = pi/180;

    thetaVals = cfg.tstart:cfg.delt:cfg.tstop;
    phiVals   = cfg.pstart:cfg.delp:cfg.pstop;

    it = numel(thetaVals);
    ip = numel(phiVals);

    theta   = zeros(ip,it);
    phi     = zeros(ip,it);
    U       = zeros(ip,it);
    V       = zeros(ip,it);
    W       = zeros(ip,it);
    Sth_raw = zeros(ip,it);
    Sph_raw = zeros(ip,it);
    Ethscat = complex(zeros(ip,it));
    Ephscat = complex(zeros(ip,it));

    % Incident wave polarization
    if cfg.i_pol == 1
        Et = 1 + 1i*0;
        Ep = 0 + 1i*0;
    else
        Et = 0 + 1i*0;
        Ep = 1 + 1i*0;
    end

    % ground plane, material layer 기능은 초기 core에서 비활성화
    grreflpar     = 0;
    grreflperp    = 0;
    groundreflect = 0;
    RCpar         = 0;
    RCperp        = 0;

    % -----------------------------
    % 5. monostatic angle loop
    % -----------------------------
    for i1 = 1:ip
        for i2 = 1:it

            phi(i1,i2)   = phiVals(i1);
            theta(i1,i2) = thetaVals(i2);

            phr = phi(i1,i2) * rad;
            thr = theta(i1,i2) * rad;

            st = sin(thr);
            ct = cos(thr);
            cp = cos(phr);
            sp = sin(phr);

            u = st*cp;
            v = st*sp;
            w = ct;

            U(i1,i2) = u;
            V(i1,i2) = v;
            W(i1,i2) = w;

            uu = ct*cp;
            vv = ct*sp;
            ww = -st;

            % Incident field in global Cartesian coordinates
            e0 = zeros(1,3);
            e0(1) = uu*Et - sp*Ep;
            e0(2) = vv*Et + cp*Ep;
            e0(3) = ww*Et;

            sumt  = 0;
            sump  = 0;
            sumdt = 0;
            sumdp = 0;

            for m = 1:ntria
                [Ets, Etd, Eps, Epd] = facetRCS( ...
                    thr, phr, thr, phr, ...
                    N(m,:), ilum(m), cfg.iflag, alpha(m), beta(m), Rs(m), Area(m), ...
                    x, y, z, vind(m,:), e0, cfg.Nt, cfg.Lt, cfac2, corel, wave, ...
                    grreflpar, grreflperp, groundreflect, cfg.rsmethod, RCpar, RCperp);

                sumt  = sumt  + Ets;
                sump  = sump  + Eps;
                sumdt = sumdt + abs(Etd);
                sumdp = sumdp + abs(Epd);
            end

            Ethscat(i1,i2) = sumt;
            Ephscat(i1,i2) = sump;

            Sth_raw(i1,i2) = 10*log10(4*pi*cfac1*(abs(sumt)^2 + sqrt(max(1-cfac1^2,0))*sumdt)/wave^2 + 1e-10);
            Sph_raw(i1,i2) = 10*log10(4*pi*cfac1*(abs(sump)^2 + sqrt(max(1-cfac1^2,0))*sumdp)/wave^2 + 1e-10);
        end
    end

    % -----------------------------
    % 6. 결과 clipping 및 요약값
    % -----------------------------
    Sth = Sth_raw;
    Sph = Sph_raw;

    Smax = max([max(Sth_raw(:)), max(Sph_raw(:))]);
    Lmax = (floor(Smax/5) + 1)*5;

    if cfg.clipFloor
        Sth = max(Sth, Lmax - 120);
        Sph = max(Sph, Lmax - 120);
    end

    RCSth_linear = 10.^(Sth_raw/10);
    RCSph_linear = 10.^(Sph_raw/10);

    metrics = struct();
    metrics.Sth_max_dBsm = max(Sth_raw(:));
    metrics.Sph_max_dBsm = max(Sph_raw(:));
    metrics.Sth_min_dBsm = min(Sth_raw(:));
    metrics.Sph_min_dBsm = min(Sph_raw(:));

    % 물리적으로 더 적절한 평균: linear 평균 후 dB 변환
    metrics.Sth_avg_dBsm_linearMean = 10*log10(mean(RCSth_linear(:)) + realmin);
    metrics.Sph_avg_dBsm_linearMean = 10*log10(mean(RCSph_linear(:)) + realmin);

    % 참고용: dB 산술평균
    metrics.Sth_avg_dBsm_arithmetic = mean(Sth_raw(:));
    metrics.Sph_avg_dBsm_arithmetic = mean(Sph_raw(:));

    if cfg.i_pol == 1
        metrics.selected_pol = 'theta';
        metrics.RCS_avg_dBsm = metrics.Sth_avg_dBsm_linearMean;
        metrics.RCS_max_dBsm = metrics.Sth_max_dBsm;
        metrics.RCS_min_dBsm = metrics.Sth_min_dBsm;
    else
        metrics.selected_pol = 'phi';
        metrics.RCS_avg_dBsm = metrics.Sph_avg_dBsm_linearMean;
        metrics.RCS_max_dBsm = metrics.Sph_max_dBsm;
        metrics.RCS_min_dBsm = metrics.Sph_min_dBsm;
    end

    % -----------------------------
    % 7. result 구조체 생성
    % -----------------------------
    result = struct();
    result.theta       = theta;
    result.phi         = phi;
    result.U           = U;
    result.V           = V;
    result.W           = W;
    result.Sth_raw     = Sth_raw;
    result.Sph_raw     = Sph_raw;
    result.Sth         = Sth;
    result.Sph         = Sph;
    result.Ethscat     = Ethscat;
    result.Ephscat     = Ephscat;
    result.RCSth_linear = RCSth_linear;
    result.RCSph_linear = RCSph_linear;
    result.metrics     = metrics;
    result.cfg         = cfg;

    result.mesh = struct();
    result.mesh.nvert  = nvert;
    result.mesh.ntria  = ntria;
    result.mesh.N      = N;
    result.mesh.Area   = Area;
    result.mesh.N      = N;
    result.mesh.Area   = Area;
    result.mesh.alpha  = alpha;
    result.mesh.beta   = beta;
    result.mesh.vind   = vind;
    result.mesh.ilum   = ilum;
    result.mesh.Rs     = Rs;

    result.wave = struct();
    result.wave.freqHz = freqHz;
    result.wave.freqGHz = cfg.freqGHz;
    result.wave.lambda = wave;
    result.wave.k = bk;

end

% -------------------------------------------------------------------------
function value = getcfg(cfg, fieldName, defaultValue)
% cfg 구조체에서 fieldName이 있으면 해당 값을 사용하고, 없으면 기본값 사용
    if isstruct(cfg) && isfield(cfg, fieldName) && ~isempty(cfg.(fieldName))
        value = cfg.(fieldName);
    else
        value = defaultValue;
    end
end
